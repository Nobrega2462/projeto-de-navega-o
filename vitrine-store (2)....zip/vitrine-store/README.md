# Vitrine Store — React Native + Expo (projeto acadêmico)

Loja virtual de roupas, tênis e acessórios que demonstra a navegação **Drawer → Bottom Tabs → Stack**.
Stack: Expo SDK 54 · React Native 0.81 · React Navigation 7 · Context API · `@expo/vector-icons` (MaterialIcons).

## Como executar (VS Code)
```bash
npm install          # instala as dependências (versões já compatíveis com o SDK 54)
npm start            # abre o menu do Expo (QR Code para o Expo Go)
npm run android      # emulador/dispositivo Android
npm run ios          # simulador iOS (somente macOS)
npm run web          # navegador
npx expo start --clear   # limpa o cache se algo estranho acontecer
```
**Expo Go:** instale a versão do Expo Go compatível com o SDK 54 e escaneie o QR Code. Todas as bibliotecas usadas
(Reanimated 4 / Worklets, Gesture Handler, Screens) já vêm no Expo Go do SDK 54, então **não é necessário development build**.
Só seria preciso um development build (`npx expo run:android`) se você adicionasse bibliotecas nativas que não estão no Expo Go.

> Se instalar pacotes novos, use `npx expo install <pacote>` para manter a versão compatível. Não rode `npm update` às cegas.

## Estrutura
```
index.js                  registerRootComponent(App)
src/App.jsx               GestureHandlerRootView > SafeAreaProvider > StoreProvider > Routes
src/theme.js              cores e formatPrice (R$ 1.129,90)
src/context/StoreContext  estado global (carrinho, favoritos, pedido, perfil, configurações)
src/data/products.js      13 produtos locais + categorias
src/routes/               index (NavigationContainer), Drawer, BottomTabs e 4 Stacks
src/screens/              11 telas
src/components/           ButtonIcon, Header, Title, ProductCard, PrimaryButton, EmptyState, ProductImage (extra)
```
Adaptações em relação à estrutura pedida: apenas arquivos extras (`theme.js`, `ProductImage.jsx`). Não há `babel.config.js`
porque o Expo SDK 54 já usa `babel-preset-expo` por padrão (inclui o plugin do Reanimated).

## Login e verificação por e-mail (demonstrativo)
- Ao abrir o app aparece o fluxo de autenticação: `login` → `register` → `verifyEmail` (`src/routes/AuthStackRoutes.jsx`).
- Cadastro: nome, e-mail e senha (mín. 6). O app gera um código de 6 dígitos (válido 10 min) e **simula o envio do e-mail**
  com um banner no topo da tela. Digitando o código a conta é verificada e o usuário entra na loja.
- Conta de teste já verificada: `demo@vitrine.com` / `123456`.
- Quem tenta entrar com conta não verificada recebe um novo código.
- `AuthContext.jsx` guarda tudo **em memória** (ao fechar o app as contas somem). Em um app real, e-mail e senha ficam em um
  backend (ex.: Firebase Authentication ou Supabase), que envia o e-mail de verdade. Sair da conta: menu ☰ ou Perfil.
- Mesmo `NavigationContainer`: ele renderiza `AuthStackRoutes` sem usuário e `DrawerRoutes` com usuário.

## Efeitos e animações
`PressableScale` (toque), `FadeIn` (entrada em cascata), `HeartButton` (coração pula), `useShake` (erro em formulário),
`animation` nos Stacks (`slide_from_right`, `fade_from_bottom`) e nas abas (`animation: "fade"` em `BottomRoutes.jsx`).

## Modo claro/escuro e fundo com foto
- `src/context/ThemeContext.jsx` guarda o tema (começa igual ao do celular). Alternar: ícone ☀/🌙 no cabeçalho, interruptor
  "Modo escuro" no menu lateral e em Configurações, ou ícone no topo das telas de login.
- As cores ficam em `src/theme.js` (`lightColors` e `darkColors`). Componentes pegam as cores com `useThemed(makeStyles)`.
- A foto de fundo é `src/assets/bg.jpg`, desenhada por `components/Background.jsx`, que a cobre com um véu semitransparente
  (`overlay` em `theme.js`). Para a foto aparecer mais, diminua o último número do `rgba(...)`; para trocar a foto, substitua o arquivo.
- `screenLayout` (React Navigation 7) aplica o fundo em cada tela dos Stacks e do Drawer.
- O tema não é salvo ao fechar o app (voltaria ao tema do celular); para salvar seria preciso `@react-native-async-storage/async-storage`.

## Fontes (Google Fonts)
Cada tipo de conteúdo tem uma fonte própria (definidas em `fonts`, em `src/theme.js`, e carregadas em `App.jsx`):
| Uso | Fonte |
|---|---|
| Nome da loja (logo e cabeçalhos) | Pacifico |
| Títulos e destaques | Playfair Display |
| Textos, botões, abas e menu | Poppins (400/500/600/700) |
| Preços e números | Montserrat |
| Códigos (verificação e pedido) | Space Mono |
O componente `src/components/Text.jsx` substitui o `Text` do React Native e escolhe a Poppins pelo `fontWeight`; para usar outra
família em um estilo, basta escrever `fontFamily: fonts.heading` (ou outra chave de `fonts`). Para trocar uma fonte, instale o pacote
`@expo-google-fonts/<nome>` e altere o nome em `theme.js` e o `useFonts` de `App.jsx`.

## Navegação
```
Drawer ("tabs" | profile | settings | help | about)
└── tabs → Bottom Tabs
    ├── homeTab      → Stack: home → productDetails
    ├── productsTab  → Stack: products → productDetails
    ├── favoritesTab → Stack: favorites → productDetails
    └── cartTab      → Stack: cart → checkout → orderConfirmation
```
- **NavigationContainer** (`routes/index.jsx`): existe uma única vez; guarda o estado de navegação e dá acesso ao `navigation` a todas as telas.
- **GestureHandlerRootView** (`App.jsx`): necessário para o gesto de arrastar do Drawer.
- **Cabeçalhos:** o Drawer usa `headerShown: false` na rota `tabs`; as abas usam `headerShown: false`; cada Stack mostra o cabeçalho
  (custom `Header.jsx` nas telas raiz, nativo com botão voltar nos detalhes). Assim nunca há dois cabeçalhos.
- Navegadores são criados **fora** dos componentes (`const Stack = createNativeStackNavigator()`).

### Passagem de parâmetros
- Card → detalhes: `navigation.navigate("productDetails", { productId })`; lido com `useRoute().params`.
- Home → filtro: `navigation.navigate("productsTab", { screen: "products", params: { category } })`.
- Qualquer tela → carrinho: `navigation.navigate("cartTab", { screen: "cart" })`.
- Checkout → confirmação: `navigation.replace("orderConfirmation", { order })` (**replace**: troca a tela, sem voltar ao checkout).
- Confirmação → loja: `navigation.popToTop()` (**popToTop**) seguido de `navigate("homeTab")`.
- Drawer: `DrawerActions.toggleDrawer()` (botão ☰ do `Header`) e `navigation.closeDrawer()` (botão "Fechar menu" do menu).
  `navigation.openDrawer()` equivale a abrir pelo gesto/ícone. `navigation.push()` só é necessário se quiser empilhar uma segunda instância da mesma tela.

### Exercícios da apostila
- Ocultar textos da barra inferior: `routes/BottomRoutes.jsx` → `tabBarShowLabel: false`.
- Menu à direita: `routes/DrawerRoutes.jsx` → `drawerPosition: "right"`.
- Empurrar a tela: `drawerType: "slide"`; menu fixo: `"permanent"` (telas grandes).

## Context API (`StoreContext.jsx`)
Guarda `cart` (`{id, qty}`) e `favorites` (IDs). Totais (`totalItems`, `subtotal`, `discount`, `shipping`, `total`) são
calculados com `useMemo`. Funções: `addToCart`, `removeFromCart`, `increaseQty`, `decreaseQty`, `clearCart`,
`addFavorite`, `removeFavorite`, `isFavorite`, `toggleFavorite`, `createOrder`. O badge do carrinho vem de `totalItems`.

## Como adicionar um produto
Inclua um objeto em `src/data/products.js` (`id` único, `category` entre Camisetas/Calças/Tênis/Acessórios, `price`,
`promoPrice` ou `null`, `image`, `stock`, `featured`, `bestSeller`). Se a URL da imagem falhar, aparece um espaço reservado.

## Como testar carrinho e checkout
1. Em *Produtos*, abra um item, escolha a quantidade e toque em **Adicionar ao carrinho** (badge da aba sobe).
2. Tente passar do estoque (botão + trava; o item some do limite). Favorite em cards/detalhes e confira na aba *Favoritos*.
3. No *Carrinho*, altere quantidades/remova; frete grátis acima de R$ 299,00.
4. **Finalizar compra** → deixe campos vazios (validação) → preencha → **Confirmar pedido** → carrinho é esvaziado.

## Erros comuns
| Erro | Solução |
|---|---|
| `NAVIGATE ... was not handled by any navigator` | Nome da rota diferente do `Stack.Screen`, ou faltou o caminho aninhado (`screen`/`params`). |
| `Couldn't find a navigation object` | Componente fora do `NavigationContainer`. |
| Drawer não abre com gesto | Falta `GestureHandlerRootView` ou dependências; reinicie com `npx expo start --clear`. |
| `ERESOLVE` no npm | Use `npx expo install` para pacotes nativos. |
| Texto cortado na barra inferior | Ajuste `height`/`paddingBottom` (já usa `useSafeAreaInsets`). |
| Dois cabeçalhos | Use `headerShown: false` no nível que não deve exibir. |
| `nested a NavigationContainer` | Mantenha só um `NavigationContainer`. |
| App "pisca" / perde estado | Criar navegadores dentro de componentes; crie-os fora. |
| Ícone quadrado/vazio | Nome inexistente em `MaterialIcons`. |
