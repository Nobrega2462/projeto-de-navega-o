import { registerRootComponent } from "expo";
import App from "./src/App";

// Registra o componente raiz para Expo Go, build nativo e web
registerRootComponent(App);
