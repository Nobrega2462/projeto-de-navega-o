// Catálogo local (sem API externa). Para adicionar um produto, basta incluir um objeto novo.
export const categories = [
  { name: "Camisetas", icon: "checkroom" },
  { name: "Calças", icon: "accessibility-new" },
  { name: "Tênis", icon: "directions-run" },
  { name: "Acessórios", icon: "watch" },
];

const U = (id) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=600&q=70`;

export const products = [
  { id: 1, name: "Camiseta Básica Algodão", category: "Camisetas", description: "Camiseta 100% algodão, modelagem reta e toque macio. Ideal para o dia a dia.", price: 69.9, promoPrice: 49.9, image: U("photo-1521572163474-6864f9cf17ab"), stock: 12, featured: true, bestSeller: true },
  { id: 2, name: "Camiseta Oversized Street", category: "Camisetas", description: "Modelagem oversized com caimento largo e tecido encorpado.", price: 89.9, promoPrice: null, image: U("photo-1583743814966-8936f5b7be1a"), stock: 8, featured: false, bestSeller: true },
  { id: 3, name: "Camiseta Polo Premium", category: "Camisetas", description: "Polo em piquet com gola firme e acabamento premium.", price: 119.9, promoPrice: 99.9, image: U("photo-1586363104862-3a5e2ab60d99"), stock: 6, featured: true, bestSeller: false },
  { id: 4, name: "Calça Jeans Slim", category: "Calças", description: "Jeans slim com elastano para maior conforto e liberdade de movimento.", price: 199.9, promoPrice: 159.9, image: U("photo-1542272604-787c3835535d"), stock: 10, featured: true, bestSeller: true },
  { id: 5, name: "Calça Jogger Urbana", category: "Calças", description: "Jogger em moletom leve com punhos ajustáveis e bolsos laterais.", price: 149.9, promoPrice: null, image: U("photo-1624378439575-d8705ad7ae80"), stock: 9, featured: false, bestSeller: false },
  { id: 6, name: "Calça Alfaiataria Chino", category: "Calças", description: "Chino de sarja com corte moderno, perfeita para ocasiões casuais e formais.", price: 229.9, promoPrice: 189.9, image: U("photo-1473966968600-fa801b869a1a"), stock: 5, featured: false, bestSeller: false },
  { id: 7, name: "Tênis Runner Pro", category: "Tênis", description: "Tênis esportivo com amortecimento reforçado e cabedal respirável.", price: 349.9, promoPrice: 279.9, image: U("photo-1542291026-7eec264c27ff"), stock: 7, featured: true, bestSeller: true },
  { id: 8, name: "Tênis Casual Branco", category: "Tênis", description: "Tênis casual minimalista, combina com qualquer look.", price: 259.9, promoPrice: null, image: U("photo-1549298916-b41d501d3772"), stock: 14, featured: false, bestSeller: true },
  { id: 9, name: "Tênis Cano Alto Classic", category: "Tênis", description: "Cano alto clássico com sola de borracha vulcanizada.", price: 299.9, promoPrice: 239.9, image: U("photo-1595950653106-6c9ebd614d3a"), stock: 4, featured: true, bestSeller: false },
  { id: 10, name: "Relógio Minimalista", category: "Acessórios", description: "Relógio analógico com pulseira de couro e caixa em aço inox.", price: 399.9, promoPrice: 329.9, image: U("photo-1523275335684-37898b6baf30"), stock: 3, featured: true, bestSeller: false },
  { id: 11, name: "Mochila Urbana 20L", category: "Acessórios", description: "Mochila resistente à água com compartimento para notebook de até 15 polegadas.", price: 179.9, promoPrice: null, image: U("photo-1553062407-98eeb64c6a62"), stock: 11, featured: false, bestSeller: true },
  { id: 12, name: "Óculos de Sol Aviador", category: "Acessórios", description: "Óculos com lentes polarizadas e proteção UV400.", price: 139.9, promoPrice: 109.9, image: U("photo-1572635196237-14b3f281503f"), stock: 15, featured: false, bestSeller: false },
  { id: 13, name: "Boné Aba Curva", category: "Acessórios", description: "Boné de algodão com ajuste traseiro e bordado frontal.", price: 59.9, promoPrice: null, image: U("photo-1588850561407-ed78c282e89b"), stock: 20, featured: false, bestSeller: false },
];

export const getProductById = (id) => products.find((p) => p.id === Number(id));
