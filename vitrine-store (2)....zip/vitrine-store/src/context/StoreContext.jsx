import React, { createContext, useContext, useMemo, useState } from "react";
import { products, getProductById } from "../data/products";

// Contexto global: carrinho, favoritos, pedido, perfil e configurações.
const StoreContext = createContext(null);

const FRETE_FIXO = 19.9;
const FRETE_GRATIS_ACIMA = 299;

export function StoreProvider({ children, initialProfile }) {
  // cart: lista de { id, qty } — guardamos só o ID e a quantidade;
  // os dados do produto vêm sempre do catálogo (fonte única da verdade).
  const [cart, setCart] = useState([]);
  const [favorites, setFavorites] = useState([]); // lista de IDs
  const [lastOrder, setLastOrder] = useState(null);
  const [profile, setProfile] = useState({ name: "Ana Souza", email: "ana.souza@exemplo.com", phone: "(21) 99999-0000", city: "Rio de Janeiro, RJ", ...initialProfile });
  const [settings, setSettings] = useState({ notifications: true, offers: false, installments: true });

  // ---------- CARRINHO ----------
  // Adiciona produto respeitando o estoque. Retorna true se adicionou.
  const addToCart = (id, qty = 1) => {
    const product = getProductById(id);
    if (!product || qty < 1) return false;
    const current = cart.find((i) => i.id === id)?.qty ?? 0;
    if (current + qty > product.stock) return false;
    setCart((prev) =>
      prev.some((i) => i.id === id)
        ? prev.map((i) => (i.id === id ? { ...i, qty: i.qty + qty } : i))
        : [...prev, { id, qty }]
    );
    return true;
  };

  const removeFromCart = (id) => setCart((prev) => prev.filter((i) => i.id !== id));

  const increaseQty = (id) => {
    const product = getProductById(id);
    setCart((prev) =>
      prev.map((i) => (i.id === id && i.qty < product.stock ? { ...i, qty: i.qty + 1 } : i))
    );
  };

  // Diminuir até 1; para zerar, o usuário usa "remover"
  const decreaseQty = (id) =>
    setCart((prev) => prev.map((i) => (i.id === id && i.qty > 1 ? { ...i, qty: i.qty - 1 } : i)));

  const clearCart = () => setCart([]);

  // ---------- FAVORITOS ----------
  const addFavorite = (id) => setFavorites((prev) => (prev.includes(id) ? prev : [...prev, id]));
  const removeFavorite = (id) => setFavorites((prev) => prev.filter((f) => f !== id));
  const isFavorite = (id) => favorites.includes(id);
  const toggleFavorite = (id) => (isFavorite(id) ? removeFavorite(id) : addFavorite(id));

  // ---------- VALORES DERIVADOS (calculados automaticamente) ----------
  const totals = useMemo(() => {
    const items = cart.map((i) => {
      const p = getProductById(i.id);
      const unit = p.promoPrice ?? p.price;
      return { ...p, qty: i.qty, unit, lineTotal: unit * i.qty };
    });
    const totalItems = items.reduce((s, i) => s + i.qty, 0);
    const subtotal = items.reduce((s, i) => s + i.lineTotal, 0);
    const originalTotal = items.reduce((s, i) => s + i.price * i.qty, 0);
    const discount = originalTotal - subtotal; // economia por preços promocionais
    const shipping = items.length === 0 || subtotal >= FRETE_GRATIS_ACIMA ? 0 : FRETE_FIXO;
    return { items, totalItems, subtotal, discount, shipping, total: subtotal + shipping };
  }, [cart]);

  // Cria um pedido demonstrativo a partir do carrinho e limpa o carrinho
  const createOrder = (customer, payment) => {
    const order = {
      id: `VS-${Date.now().toString().slice(-6)}`,
      customer,
      payment,
      items: totals.items.map((i) => ({ id: i.id, name: i.name, qty: i.qty, unit: i.unit })),
      subtotal: totals.subtotal,
      shipping: totals.shipping,
      total: totals.total,
    };
    setLastOrder(order);
    clearCart();
    return order;
  };

  const value = {
    products, cart, favorites, lastOrder, profile, setProfile, settings, setSettings,
    addToCart, removeFromCart, increaseQty, decreaseQty, clearCart,
    addFavorite, removeFavorite, isFavorite, toggleFavorite, createOrder,
    ...totals,
    freeShippingFrom: FRETE_GRATIS_ACIMA,
  };
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore deve ser usado dentro de <StoreProvider>");
  return ctx;
}
