import React, { createContext, useContext, useMemo, useState } from "react";
import { useColorScheme } from "react-native";
import { lightColors, darkColors } from "../theme";

// Tema claro/escuro. Começa seguindo o tema do celular e pode ser alternado pelo usuário.
const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const system = useColorScheme();
  const [dark, setDark] = useState(system === "dark");
  const value = useMemo(
    () => ({ dark, colors: dark ? darkColors : lightColors, setDark, toggleTheme: () => setDark((d) => !d) }),
    [dark]
  );
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme deve ser usado dentro de <ThemeProvider>");
  return ctx;
}

// Cria os estilos a partir das cores do tema atual (recalcula só quando o tema muda)
export function useThemed(makeStyles) {
  const { colors } = useTheme();
  const styles = useMemo(() => makeStyles(colors), [colors]);
  return { colors, styles };
}
