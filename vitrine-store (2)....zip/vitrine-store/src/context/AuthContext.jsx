import React, { createContext, useContext, useRef, useState } from "react";

// Autenticação DEMONSTRATIVA (somente em memória, sem servidor).
// O "e-mail" de verificação é simulado: o código aparece num banner dentro do app.
// Em um app real, o envio do e-mail e a checagem de senha ficariam em um backend
// (ex.: Firebase Authentication, Supabase). Senhas nunca devem ser guardadas assim.
const AuthContext = createContext(null);

export const isValidEmail = (e) => /^\S+@\S+\.\S+$/.test(e.trim());
const norm = (e) => e.trim().toLowerCase();

// Conta já verificada para testar rápido
const DEMO = { name: "Usuário Demo", email: "demo@vitrine.com", password: "123456", verified: true };

export function AuthProvider({ children }) {
  const [accounts, setAccounts] = useState([DEMO]);
  const [user, setUser] = useState(null); // usuário logado { name, email }
  const [inbox, setInbox] = useState(null); // e-mail simulado { to, code, key }
  const codes = useRef({}); // { email: { code, expires } }

  // Gera um código de 6 dígitos válido por 10 minutos e "envia" o e-mail simulado
  const sendCode = (email) => {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    codes.current[email] = { code, expires: Date.now() + 10 * 60 * 1000 };
    setInbox({ to: email, code, key: Date.now() });
  };

  const register = (name, emailRaw, password) => {
    const email = norm(emailRaw);
    const existing = accounts.find((a) => a.email === email);
    if (existing?.verified) return { ok: false, error: "Este e-mail já está cadastrado." };
    const account = { name: name.trim(), email, password, verified: false };
    setAccounts((prev) => [...prev.filter((a) => a.email !== email), account]);
    sendCode(email);
    return { ok: true, email };
  };

  const login = (emailRaw, password) => {
    const email = norm(emailRaw);
    const acc = accounts.find((a) => a.email === email && a.password === password);
    if (!acc) return { ok: false, error: "E-mail ou senha incorretos." };
    if (!acc.verified) {
      sendCode(email); // conta ainda não verificada: reenvia o código
      return { ok: false, needsVerification: true, email };
    }
    setInbox(null);
    setUser({ name: acc.name, email: acc.email });
    return { ok: true };
  };

  const verifyEmail = (emailRaw, code) => {
    const email = norm(emailRaw);
    const entry = codes.current[email];
    if (!entry) return { ok: false, error: "Solicite um novo código." };
    if (Date.now() > entry.expires) return { ok: false, error: "Código expirado. Reenvie." };
    if (entry.code !== code.trim()) return { ok: false, error: "Código incorreto." };
    const acc = accounts.find((a) => a.email === email);
    setAccounts((prev) => prev.map((a) => (a.email === email ? { ...a, verified: true } : a)));
    delete codes.current[email];
    setInbox(null);
    setUser({ name: acc.name, email });
    return { ok: true };
  };

  const resendCode = (email) => sendCode(norm(email));
  const logout = () => setUser(null);

  return (
    <AuthContext.Provider value={{ user, inbox, dismissInbox: () => setInbox(null), register, login, verifyEmail, resendCode, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth deve ser usado dentro de <AuthProvider>");
  return ctx;
}
