import React from "react";
import { View, ActivityIndicator } from "react-native";
import { StatusBar } from "expo-status-bar";
import { useFonts } from "expo-font";
import { Pacifico_400Regular } from "@expo-google-fonts/pacifico";
import { PlayfairDisplay_700Bold } from "@expo-google-fonts/playfair-display";
import { Poppins_400Regular, Poppins_500Medium, Poppins_600SemiBold, Poppins_700Bold } from "@expo-google-fonts/poppins";
import { Montserrat_700Bold, Montserrat_800ExtraBold } from "@expo-google-fonts/montserrat";
import { SpaceMono_400Regular, SpaceMono_700Bold } from "@expo-google-fonts/space-mono";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { ThemeProvider } from "./context/ThemeContext";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { StoreProvider } from "./context/StoreContext";
import { fonts } from "./theme";
import Routes from "./routes";

// A loja é recriada (key) a cada troca de usuário: carrinho e favoritos não vazam entre contas
function Root() {
  const { user } = useAuth();
  return (
    <StoreProvider key={user ? user.email : "guest"} initialProfile={user ? { name: user.name, email: user.email } : undefined}>
      <StatusBar style="light" />
      <Routes />
    </StoreProvider>
  );
}

export default function App() {
  // Carrega as fontes (as chaves precisam ser iguais aos nomes usados em `fonts`, em theme.js)
  const [loaded, error] = useFonts({
    [fonts.brand]: Pacifico_400Regular,
    [fonts.heading]: PlayfairDisplay_700Bold,
    [fonts.body]: Poppins_400Regular,
    [fonts.bodyMedium]: Poppins_500Medium,
    [fonts.bodySemi]: Poppins_600SemiBold,
    [fonts.bodyBold]: Poppins_700Bold,
    [fonts.price]: Montserrat_700Bold,
    [fonts.priceBold]: Montserrat_800ExtraBold,
    [fonts.mono]: SpaceMono_400Regular,
    [fonts.monoBold]: SpaceMono_700Bold,
  });

  // Enquanto as fontes carregam, mostra uma tela roxa com indicador de carregamento
  if (!loaded && !error) {
    return (
      <View style={{ flex: 1, backgroundColor: "#7C3AED", alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator size="large" color="#FFFFFF" />
      </View>
    );
  }

  return (
    // GestureHandlerRootView (flex:1) é necessário para o gesto de arrastar do Drawer
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <ThemeProvider>
          <AuthProvider>
            <Root />
          </AuthProvider>
        </ThemeProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
