import React, { useRef } from "react";
import { Animated, Pressable, Platform } from "react-native";

// Pressable com efeito de "afundar" (escala) ao tocar. 
// outerStyle = layout externo (posição/flex/margem); style = aparência do conteúdo.
export default function PressableScale({ children, style, outerStyle, scaleTo = 0.95, onPress, ...rest }) {
  const s = useRef(new Animated.Value(1)).current;
  const to = (v) => Animated.spring(s, { toValue: v, speed: 40, bounciness: 8, useNativeDriver: Platform.OS !== "web" }).start();
  return (
    <Pressable onPressIn={() => to(scaleTo)} onPressOut={() => to(1)} onPress={onPress} style={outerStyle} {...rest}>
      <Animated.View style={[style, { transform: [{ scale: s }] }]}>{children}</Animated.View>
    </Pressable>
  );
}
