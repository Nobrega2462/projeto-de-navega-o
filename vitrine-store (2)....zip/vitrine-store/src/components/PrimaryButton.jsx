import React from "react";
import { ActivityIndicator, StyleSheet } from "react-native";
import Text from "./Text";
import { MaterialIcons } from "@expo/vector-icons";
import PressableScale from "./PressableScale";
import { useThemed } from "../context/ThemeContext";

// Botão principal (roxo) com efeito de toque. variant="outline" = versão secundária.
export default function PrimaryButton({ title, onPress, icon, disabled, loading, variant = "solid", style }) {
  const { colors, styles } = useThemed(makeStyles);
  const outline = variant === "outline";
  const fg = outline ? colors.primary : colors.white;
  return (
    <PressableScale
      onPress={onPress}
      disabled={disabled || loading}
      outerStyle={[disabled && { opacity: 0.5 }, style]}
      style={[styles.btn, outline ? styles.outline : styles.solid]}
    >
      {loading ? (
        <ActivityIndicator color={fg} />
      ) : (
        <>
          {icon ? <MaterialIcons name={icon} size={20} color={fg} style={{ marginRight: 8 }} /> : null}
          <Text style={[styles.text, { color: fg }]}>{title}</Text>
        </>
      )}
    </PressableScale>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  btn: { flexDirection: "row", alignItems: "center", justifyContent: "center", paddingVertical: 14, paddingHorizontal: 20, borderRadius: 14, minHeight: 50 },
  solid: { backgroundColor: colors.primary },
  outline: { borderWidth: 1.5, borderColor: colors.primary, backgroundColor: colors.surface },
  text: { fontSize: 16, fontWeight: "700" },
});
