import { useRef } from "react";
import { Animated, Platform } from "react-native";

// "Tremida" para indicar erro em formulários. Uso: const [shakeStyle, shake] = useShake();
export default function useShake() {
  const x = useRef(new Animated.Value(0)).current;
  const nd = Platform.OS !== "web";
  const shake = () =>
    Animated.sequence([10, -10, 8, -8, 4, 0].map((v) => Animated.timing(x, { toValue: v, duration: 55, useNativeDriver: nd }))).start();
  return [{ transform: [{ translateX: x }] }, shake];
}
