import React from "react";
import { MaterialIcons } from "@expo/vector-icons";
import PressableScale from "./PressableScale";
import { useTheme } from "../context/ThemeContext";

// Botão apenas com ícone, com efeito de toque. A cor padrão acompanha o tema.
export default function ButtonIcon({ name, size = 24, color, onPress, label, style, background }) {
  const { colors } = useTheme();
  return (
    <PressableScale
      onPress={onPress}
      scaleTo={0.85}
      accessibilityRole="button"
      accessibilityLabel={label}
      hitSlop={8}
      outerStyle={style}
      style={{ padding: 6, borderRadius: 20, backgroundColor: background }}
    >
      <MaterialIcons name={name} size={size} color={color ?? colors.text} />
    </PressableScale>
  );
}
