import React from "react";
import { fonts } from "../theme";
import { View, StyleSheet } from "react-native";
import Text from "./Text";
import { useNavigation } from "@react-navigation/native";
import ProductImage from "./ProductImage";
import HeartButton from "./HeartButton";
import PressableScale from "./PressableScale";
import { useStore } from "../context/StoreContext";
import { formatPrice } from "../theme";
import { useThemed } from "../context/ThemeContext";

// Cartão de produto reutilizado na Home, Produtos e Favoritos (com efeito de toque).
export default function ProductCard({ product, width }) {
  const { colors, styles } = useThemed(makeStyles);
  const navigation = useNavigation();
  const { isFavorite, toggleFavorite, settings } = useStore();
  const fav = isFavorite(product.id);
  const final = product.promoPrice ?? product.price;
  const off = product.promoPrice ? Math.round((1 - product.promoPrice / product.price) * 100) : 0;

  // Passagem de parâmetros: o stack atual possui a rota "productDetails"
  const open = () => navigation.navigate("productDetails", { productId: product.id });

  return (
    <PressableScale onPress={open} scaleTo={0.97} outerStyle={width ? { width } : { flex: 1 }} style={styles.card}>
      <View>
        <ProductImage uri={product.image} style={styles.img} />
        {off > 0 && (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>-{off}%</Text>
          </View>
        )}
        <HeartButton active={fav} onPress={() => toggleFavorite(product.id)} style={styles.fav} />
      </View>
      <View style={styles.info}>
        <Text style={styles.name} numberOfLines={2}>{product.name}</Text>
        {product.promoPrice ? <Text style={styles.old}>{formatPrice(product.price)}</Text> : null}
        <Text style={styles.price}>{formatPrice(final)}</Text>
        {settings.installments && <Text style={styles.inst}>ou 10x de {formatPrice(final / 10)}</Text>}
        <View style={styles.btn}>
          <Text style={styles.btnText}>Ver detalhes</Text>
        </View>
      </View>
    </PressableScale>
  );
}

const makeStyles = (colors) => StyleSheet.create({
  card: { backgroundColor: colors.surface, borderRadius: 16, overflow: "hidden", borderWidth: 1, borderColor: colors.border, margin: 6 },
  img: { width: "100%", height: 150 },
  badge: { position: "absolute", left: 8, top: 8, backgroundColor: colors.danger, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 },
  badgeText: { fontFamily: fonts.price, color: colors.white, fontWeight: "700", fontSize: 12 },
  fav: { position: "absolute", right: 8, top: 8 },
  info: { padding: 10 },
  name: { fontSize: 14, fontWeight: "600", color: colors.text, minHeight: 36 },
  old: { fontFamily: fonts.price, fontSize: 12, color: colors.gray, textDecorationLine: "line-through", marginTop: 4 },
  price: { fontFamily: fonts.priceBold, fontSize: 17, fontWeight: "800", color: colors.primary },
  inst: { fontFamily: fonts.body, fontSize: 11, color: colors.textSoft },
  btn: { marginTop: 8, backgroundColor: colors.primaryLight, borderRadius: 10, paddingVertical: 8, alignItems: "center" },
  btnText: { color: colors.primary, fontWeight: "700", fontSize: 13 },
});
