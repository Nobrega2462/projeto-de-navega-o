import React, { useEffect, useRef } from "react";
import { fonts } from "../theme";
import { View, Animated, Platform, StyleSheet } from "react-native";
import Text from "./Text";
import { MaterialIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import ButtonIcon from "./ButtonIcon";
import { useAuth } from "../context/AuthContext";
import { useThemed } from "../context/ThemeContext";

// Simula a chegada do e-mail de verificação (desce do topo da tela)
export default function EmailBanner() {
  const { colors, styles } = useThemed(makeStyles);
  const { inbox, dismissInbox } = useAuth();
  const insets = useSafeAreaInsets();
  const y = useRef(new Animated.Value(-220)).current;

  useEffect(() => {
    if (inbox) {
      y.setValue(-220);
      Animated.spring(y, { toValue: 0, friction: 7, useNativeDriver: Platform.OS !== "web" }).start();
    }
  }, [inbox?.key]);

  if (!inbox) return null;
  return (
    <Animated.View style={[styles.wrap, { top: insets.top + 6, transform: [{ translateY: y }] }]}>
      <MaterialIcons name="mark-email-unread" size={26} color={colors.primary} />
      <View style={{ flex: 1, marginHorizontal: 10 }}>
        <Text style={styles.title}>E-mail simulado para {inbox.to}</Text>
        <Text style={styles.code}>Seu código: <Text style={{ fontWeight: "900", letterSpacing: 3 }}>{inbox.code}</Text></Text>
        <Text style={styles.note}>Demonstração: em um app real o código chegaria na caixa de entrada.</Text>
      </View>
      <ButtonIcon name="close" size={20} color={colors.textSoft} label="Fechar" onPress={dismissInbox} />
    </Animated.View>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  wrap: { position: "absolute", left: 12, right: 12, zIndex: 99, flexDirection: "row", alignItems: "center", backgroundColor: colors.surface, borderRadius: 16, padding: 12, borderWidth: 1, borderColor: colors.primaryLight, elevation: 8, shadowColor: "#000", shadowOpacity: 0.18, shadowRadius: 12, shadowOffset: { width: 0, height: 4 } },
  title: { fontSize: 12, color: colors.textSoft },
  code: { fontFamily: fonts.mono, fontSize: 18, color: colors.text, marginTop: 2 },
  note: { fontSize: 11, color: colors.gray, marginTop: 2 },
});
