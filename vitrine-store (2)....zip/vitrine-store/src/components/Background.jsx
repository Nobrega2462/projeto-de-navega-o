import React from "react";
import { View, Image, StyleSheet } from "react-native";
import { useTheme } from "../context/ThemeContext";

const bg = require("../assets/bg.jpg");

// Fundo das telas: foto + véu semitransparente (claro ou escuro) para manter textos legíveis.
// Para a foto aparecer mais/menos, ajuste `overlay` em src/theme.js.
export default function Background({ children, tint }) {
  const { colors } = useTheme();
  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Image source={bg} resizeMode="cover" style={StyleSheet.absoluteFill} />
      <View style={[StyleSheet.absoluteFill, { backgroundColor: tint ?? colors.overlay, pointerEvents: "none" }]} />
      {children}
    </View>
  );
}
