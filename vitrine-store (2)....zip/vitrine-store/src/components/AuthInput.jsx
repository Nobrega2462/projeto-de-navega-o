import React, { useState } from "react";
import { fonts } from "../theme";
import { View, TextInput, Pressable, StyleSheet } from "react-native";
import Text from "./Text";
import { MaterialIcons } from "@expo/vector-icons";
import { useThemed } from "../context/ThemeContext";

// Campo de texto das telas de login/cadastro, com ícone, erro e botão de mostrar senha
export default function AuthInput({ label, icon, error, secure, mono, ...rest }) {
  const { colors, styles } = useThemed(makeStyles);
  const [hidden, setHidden] = useState(!!secure);
  const [focus, setFocus] = useState(false);
  return (
    <View style={{ marginBottom: 12 }}>
      <Text style={styles.label}>{label}</Text>
      <View style={[styles.box, focus && { borderColor: colors.primary }, error && { borderColor: colors.danger }]}>
        <MaterialIcons name={icon} size={20} color={focus ? colors.primary : colors.gray} />
        <TextInput
          style={[styles.input, mono && { fontFamily: fonts.monoBold, letterSpacing: 8, fontSize: 20 }]}
          secureTextEntry={hidden}
          autoCapitalize="none"
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          placeholderTextColor={colors.gray}
          {...rest}
        />
        {secure && (
          <Pressable onPress={() => setHidden((h) => !h)} hitSlop={8}>
            <MaterialIcons name={hidden ? "visibility" : "visibility-off"} size={20} color={colors.gray} />
          </Pressable>
        )}
      </View>
      {error ? <Text style={styles.err}>{error}</Text> : null}
    </View>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  label: { fontSize: 13, color: colors.textSoft, marginBottom: 5, fontWeight: "600" },
  box: { flexDirection: "row", alignItems: "center", backgroundColor: colors.grayLight, borderRadius: 14, borderWidth: 1.5, borderColor: "transparent", paddingHorizontal: 12 },
  input: { fontFamily: fonts.body, flex: 1, paddingVertical: 13, paddingHorizontal: 8, fontSize: 15, color: colors.text, outlineStyle: "none" },
  err: { color: colors.danger, fontSize: 12, marginTop: 4 },
});
