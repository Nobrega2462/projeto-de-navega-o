import React, { useState } from "react";
import { View, Image } from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { useTheme } from "../context/ThemeContext";

// Imagem com espaço reservado caso a URL falhe (evita tela quebrada)
export default function ProductImage({ uri, style }) {
  const { colors } = useTheme();
  const [failed, setFailed] = useState(false);
  if (failed || !uri) {
    return (
      <View style={[{ backgroundColor: colors.primaryLight, alignItems: "center", justifyContent: "center" }, style]}>
        <MaterialIcons name="image" size={40} color={colors.primary} />
      </View>
    );
  }
  return <Image source={{ uri }} style={style} resizeMode="cover" onError={() => setFailed(true)} />;
}
