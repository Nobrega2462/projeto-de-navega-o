import React, { useEffect, useRef } from "react";
import { Animated, Platform } from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import PressableScale from "./PressableScale";
import { useTheme } from "../context/ThemeContext";

// Botão de favorito: o coração "pula" quando é marcado/desmarcado
export default function HeartButton({ active, onPress, size = 22, background, style }) {
  const { colors } = useTheme();
  const s = useRef(new Animated.Value(1)).current;
  const first = useRef(true);
  useEffect(() => {
    if (first.current) { first.current = false; return; }
    const nd = Platform.OS !== "web";
    Animated.sequence([
      Animated.timing(s, { toValue: 1.45, duration: 120, useNativeDriver: nd }),
      Animated.spring(s, { toValue: 1, friction: 4, useNativeDriver: nd }),
    ]).start();
  }, [active]);
  return (
    <PressableScale onPress={onPress} outerStyle={style} accessibilityRole="button" accessibilityLabel="Favoritar" hitSlop={8}>
      <Animated.View style={{ transform: [{ scale: s }], padding: 6, borderRadius: 20, backgroundColor: background ?? colors.surface }}>
        <MaterialIcons name={active ? "favorite" : "favorite-border"} size={size} color={active ? colors.danger : colors.textSoft} />
      </Animated.View>
    </PressableScale>
  );
}
