import React from "react";
import { Text as RNText, StyleSheet } from "react-native";
import { fonts } from "../theme";

// <Text> do app: escolhe a fonte Poppins pelo fontWeight do estilo.
// Se o estilo já trouxer fontFamily (ex.: fonts.heading), ele é respeitado.
// O fontWeight é removido porque fontes personalizadas já têm o peso embutido (evita falhas no Android).
export default function Text({ style, ...rest }) {
  const { fontWeight, fontFamily, ...others } = StyleSheet.flatten(style) || {};
  let family = fontFamily;
  if (!family) {
    const w = fontWeight === "bold" ? 700 : Number(fontWeight ?? 400);
    family = w >= 700 ? fonts.bodyBold : w >= 600 ? fonts.bodySemi : w >= 500 ? fonts.bodyMedium : fonts.body;
  }
  return <RNText {...rest} style={[others, { fontFamily: family }]} />;
}
