import React, { useEffect, useRef } from "react";
import { Animated, Easing, Platform } from "react-native";

// Efeito de entrada: aparece com fade e sobe suavemente. `delay` permite efeito em cascata.
export default function FadeIn({ children, delay = 0, from = 18, duration = 420, style }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(v, { toValue: 1, duration, delay, easing: Easing.out(Easing.cubic), useNativeDriver: Platform.OS !== "web" }).start();
  }, []);
  return (
    <Animated.View style={[style, { opacity: v, transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [from, 0] }) }] }]}>
      {children}
    </Animated.View>
  );
}
