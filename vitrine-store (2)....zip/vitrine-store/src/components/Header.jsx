import React from "react";
import { fonts } from "../theme";
import { View, StyleSheet } from "react-native";
import Text from "./Text";
import { useNavigation, DrawerActions } from "@react-navigation/native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import ButtonIcon from "./ButtonIcon";
import { useStore } from "../context/StoreContext";
import { useThemed, useTheme } from "../context/ThemeContext";

// Cabeçalho personalizado usado nas telas RAIZ de cada Stack.
// As telas de detalhe usam o cabeçalho nativo do Stack (com botão de voltar).
// O menu lateral é aberto com DrawerActions: a ação "sobe" até o Drawer pai.
export default function Header({ title = "Vitrine Store", showSearch, showCart }) {
  const { colors, styles } = useThemed(makeStyles);
  const { dark, toggleTheme } = useTheme();
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const { totalItems } = useStore();

  return (
    <View style={[styles.bar, { paddingTop: insets.top + 8 }]}>
      <ButtonIcon name="menu" color={colors.white} label="Abrir menu" onPress={() => navigation.dispatch(DrawerActions.toggleDrawer())} />
      <Text style={styles.title}>{title}</Text>
      <ButtonIcon name={dark ? "light-mode" : "dark-mode"} color={colors.white} label="Alternar modo claro/escuro" onPress={toggleTheme} />
      {showSearch && (
        <ButtonIcon name="search" color={colors.white} label="Pesquisar" onPress={() => navigation.navigate("productsTab", { screen: "products" })} />
      )}
      {showCart && (
        <View>
          <ButtonIcon name="shopping-cart" color={colors.white} label="Carrinho" onPress={() => navigation.navigate("cartTab", { screen: "cart" })} />
          {totalItems > 0 && (
            <View style={styles.dot}><Text style={styles.dotText}>{totalItems}</Text></View>
          )}
        </View>
      )}
    </View>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  bar: { backgroundColor: colors.primary, flexDirection: "row", alignItems: "center", paddingHorizontal: 12, paddingBottom: 10 },
  title: { fontFamily: fonts.brand, flex: 1, color: colors.white, fontSize: 20, fontWeight: "800", marginLeft: 8 },
  dot: { position: "absolute", right: -2, top: -2, backgroundColor: colors.danger, borderRadius: 9, minWidth: 18, height: 18, alignItems: "center", justifyContent: "center", paddingHorizontal: 4 },
  dotText: { fontFamily: fonts.price, color: colors.white, fontSize: 11, fontWeight: "700" },
});
