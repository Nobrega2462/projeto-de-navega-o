import React, { useEffect, useRef } from "react";
import { fonts } from "../theme";
import { View, ScrollView, KeyboardAvoidingView, Platform, Animated, StyleSheet } from "react-native";
import Text from "./Text";
import { MaterialIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import ButtonIcon from "./ButtonIcon";
import FadeIn from "./FadeIn";
import Background from "./Background";
import { useThemed, useTheme } from "../context/ThemeContext";

// Estrutura visual comum de Login, Cadastro e Verificação:
// topo com a foto de fundo (véu roxo) + logo, e um cartão com o formulário.
export default function AuthLayout({ title, subtitle, children, onBack }) {
  const { colors, styles } = useThemed(makeStyles);
  const { dark, toggleTheme } = useTheme();
  const insets = useSafeAreaInsets();
  const logo = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.spring(logo, { toValue: 1, friction: 5, tension: 60, useNativeDriver: Platform.OS !== "web" }).start();
  }, []);

  return (
    <Background tint="rgba(76,29,149,0.78)">
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <View style={[styles.top, { paddingTop: insets.top + 28 }]}>
            {onBack && <ButtonIcon name="arrow-back" color={colors.white} label="Voltar" onPress={onBack} style={{ position: "absolute", left: 12, top: insets.top + 8 }} />}
            <ButtonIcon name={dark ? "light-mode" : "dark-mode"} color={colors.white} label="Alternar modo claro/escuro" onPress={toggleTheme}
              style={{ position: "absolute", right: 12, top: insets.top + 8 }} />
            <Animated.View style={[styles.logo, { opacity: logo, transform: [{ scale: logo.interpolate({ inputRange: [0, 1], outputRange: [0.4, 1] }) }] }]}>
              <MaterialIcons name="storefront" size={44} color="#7C3AED" />
            </Animated.View>
            <Text style={styles.brand}>Vitrine Store</Text>
          </View>
          <FadeIn style={styles.card} delay={150}>
            <Text style={styles.title}>{title}</Text>
            {subtitle ? <Text style={styles.sub}>{subtitle}</Text> : null}
            {children}
          </FadeIn>
        </ScrollView>
      </KeyboardAvoidingView>
    </Background>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  top: { alignItems: "center", paddingBottom: 28 },
  logo: { width: 84, height: 84, borderRadius: 26, backgroundColor: colors.white, alignItems: "center", justifyContent: "center" },
  brand: { fontFamily: fonts.brand, color: colors.white, fontSize: 26, fontWeight: "800", marginTop: 12 },
  card: { flexGrow: 1, backgroundColor: colors.surface, borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 24, paddingBottom: 40 },
  title: { fontFamily: fonts.heading, fontSize: 24, fontWeight: "800", color: colors.text },
  sub: { color: colors.textSoft, marginTop: 4, marginBottom: 18, lineHeight: 20 },
});
