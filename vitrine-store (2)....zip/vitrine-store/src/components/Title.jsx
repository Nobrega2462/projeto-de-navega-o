import React from "react";
import { fonts } from "../theme";
import { View, StyleSheet } from "react-native";
import Text from "./Text";
import { useThemed } from "../context/ThemeContext";

// Título de seção com subtítulo opcional e ação à direita (ex.: "Ver tudo")
export default function Title({ title, subtitle, right }) {
  const { colors, styles } = useThemed(makeStyles);
  return (
    <View style={styles.row}>
      <View style={{ flex: 1 }}>
        <Text style={styles.title}>{title}</Text>
        {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
      </View>
      {right}
    </View>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", marginBottom: 12, marginTop: 8 },
  title: { fontFamily: fonts.heading, fontSize: 18, fontWeight: "700", color: colors.text },
  subtitle: { fontSize: 13, color: colors.textSoft, marginTop: 2 },
});
