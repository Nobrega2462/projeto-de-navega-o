import React from "react";
import { fonts } from "../theme";
import { View, StyleSheet } from "react-native";
import Text from "./Text";
import { MaterialIcons } from "@expo/vector-icons";
import PrimaryButton from "./PrimaryButton";
import { useThemed } from "../context/ThemeContext";

// Mensagem amigável para listas vazias (carrinho, favoritos, busca sem resultado)
export default function EmptyState({ icon = "inbox", title, message, buttonTitle, onPress }) {
  const { colors, styles } = useThemed(makeStyles);
  return (
    <View style={styles.box}>
      <View style={styles.circle}>
        <MaterialIcons name={icon} size={44} color={colors.primary} />
      </View>
      <Text style={styles.title}>{title}</Text>
      {message ? <Text style={styles.msg}>{message}</Text> : null}
      {buttonTitle ? <PrimaryButton title={buttonTitle} onPress={onPress} style={{ marginTop: 20 }} /> : null}
    </View>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  box: { alignItems: "center", justifyContent: "center", padding: 32, flexGrow: 1 },
  circle: { width: 88, height: 88, borderRadius: 44, backgroundColor: colors.primaryLight, alignItems: "center", justifyContent: "center", marginBottom: 16 },
  title: { fontFamily: fonts.heading, fontSize: 18, fontWeight: "700", color: colors.text, textAlign: "center" },
  msg: { fontSize: 14, color: colors.textSoft, textAlign: "center", marginTop: 6 },
});
