import React, { useState } from "react";
import { fonts } from "../theme";
import { ScrollView, View, TextInput, Pressable, StyleSheet } from "react-native";
import Text from "../components/Text";
import { MaterialIcons } from "@expo/vector-icons";
import PrimaryButton from "../components/PrimaryButton";
import PressableScale from "../components/PressableScale";
import EmptyState from "../components/EmptyState";
import { useStore } from "../context/StoreContext";
import { formatPrice } from "../theme";
import { useThemed } from "../context/ThemeContext";

const PAYMENTS = [
  { key: "Pix", icon: "qr-code-2" },
  { key: "Cartão", icon: "credit-card" },
  { key: "Boleto", icon: "receipt" },
];

export default function Checkout({ navigation }) {
  const { colors, styles } = useThemed(makeStyles);
  const { items, subtotal, shipping, discount, total, createOrder } = useStore();
  const [form, setForm] = useState({ name: "", email: "", phone: "", cep: "", address: "", number: "", complement: "" });
  const [payment, setPayment] = useState("Pix");
  const [errors, setErrors] = useState({});

  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));
  const digits = (s) => s.replace(/\D/g, "");

  // Valida os campos obrigatórios antes de confirmar
  const validate = () => {
    const e = {};
    if (form.name.trim().length < 3) e.name = "Informe seu nome completo";
    if (!/^\S+@\S+\.\S+$/.test(form.email)) e.email = "E-mail inválido";
    if (![10, 11].includes(digits(form.phone).length)) e.phone = "Telefone com DDD (10 ou 11 dígitos)";
    if (digits(form.cep).length !== 8) e.cep = "CEP com 8 dígitos";
    if (form.address.trim().length < 3) e.address = "Informe o endereço";
    if (!form.number.trim()) e.number = "Informe o número";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const confirm = () => {
    if (!validate()) return;
    const order = createOrder(form, payment); // cria pedido e limpa o carrinho
    // replace(): troca o checkout pela confirmação (não dá para "voltar" ao checkout)
    navigation.replace("orderConfirmation", { order });
  };

  if (items.length === 0) {
    return <EmptyState icon="shopping-cart" title="Carrinho vazio" buttonTitle="Voltar ao carrinho" onPress={() => navigation.popToTop()} />;
  }

  const Field = ({ k, label, ...rest }) => (
    <View style={{ marginBottom: 10 }}>
      <Text style={styles.label}>{label}</Text>
      <TextInput placeholderTextColor={colors.gray} style={[styles.input, errors[k] && { borderColor: colors.danger }]} value={form[k]} onChangeText={set(k)} {...rest} />
      {errors[k] ? <Text style={styles.err}>{errors[k]}</Text> : null}
    </View>
  );

  return (
    <ScrollView style={{ backgroundColor: "transparent" }} contentContainerStyle={{ padding: 16, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
      <Text style={styles.h}>Seus dados</Text>
      {Field({ k: "name", label: "Nome completo", placeholder: "Seu nome" })}
      {Field({ k: "email", label: "E-mail", placeholder: "voce@email.com", keyboardType: "email-address", autoCapitalize: "none" })}
      {Field({ k: "phone", label: "Telefone", placeholder: "(21) 99999-0000", keyboardType: "phone-pad" })}

      <Text style={styles.h}>Entrega</Text>
      {Field({ k: "cep", label: "CEP", placeholder: "00000-000", keyboardType: "numeric" })}
      {Field({ k: "address", label: "Endereço", placeholder: "Rua, avenida..." })}
      {Field({ k: "number", label: "Número", placeholder: "123", keyboardType: "numeric" })}
      {Field({ k: "complement", label: "Complemento (opcional)", placeholder: "Apto, bloco..." })}

      <Text style={styles.h}>Forma de pagamento (demonstrativa)</Text>
      <View style={{ flexDirection: "row", gap: 8 }}>
        {PAYMENTS.map((p) => (
          <PressableScale key={p.key} onPress={() => setPayment(p.key)} outerStyle={{ flex: 1 }} style={[styles.pay, payment === p.key && styles.payOn]}>
            <MaterialIcons name={p.icon} size={24} color={payment === p.key ? colors.white : colors.primary} />
            <Text style={[styles.payText, payment === p.key && { color: colors.white }]}>{p.key}</Text>
          </PressableScale>
        ))}
      </View>
      <Text style={styles.note}>Projeto acadêmico: nenhum pagamento real é processado e nenhum dado financeiro é solicitado.</Text>

      <Text style={styles.h}>Resumo</Text>
      <View style={styles.box}>
        {items.map((i) => (
          <View key={i.id} style={styles.line}>
            <Text style={{ flex: 1, color: colors.text }}>{i.qty}x {i.name}</Text>
            <Text style={{ fontWeight: "700", color: colors.text }}>{formatPrice(i.lineTotal)}</Text>
          </View>
        ))}
        <View style={styles.line}><Text style={{ color: colors.text }}>Subtotal</Text><Text style={{ color: colors.text }}>{formatPrice(subtotal)}</Text></View>
        <View style={styles.line}><Text style={{ color: colors.text }}>Frete</Text><Text style={{ color: colors.text }}>{shipping === 0 ? "Grátis" : formatPrice(shipping)}</Text></View>
        {discount > 0 && <View style={styles.line}><Text style={{ color: colors.success }}>Economia</Text><Text style={{ color: colors.success }}>- {formatPrice(discount)}</Text></View>}
        <View style={styles.line}><Text style={styles.total}>Total</Text><Text style={styles.total}>{formatPrice(total)}</Text></View>
      </View>

      <PrimaryButton title="Confirmar pedido" icon="check" onPress={confirm} style={{ marginTop: 16 }} />
    </ScrollView>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  h: { fontFamily: fonts.heading, fontSize: 17, fontWeight: "800", color: colors.text, marginTop: 14, marginBottom: 8 },
  label: { fontSize: 13, color: colors.textSoft, marginBottom: 4 },
  input: { fontFamily: fonts.body, borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 11, fontSize: 15, color: colors.text, backgroundColor: colors.grayLight },
  err: { color: colors.danger, fontSize: 12, marginTop: 3 },
  pay: { flex: 1, alignItems: "center", paddingVertical: 12, borderRadius: 14, borderWidth: 1.5, borderColor: colors.primary },
  payOn: { backgroundColor: colors.primary },
  payText: { color: colors.primary, fontWeight: "700", marginTop: 4 },
  note: { fontSize: 12, color: colors.textSoft, marginTop: 8 },
  box: { backgroundColor: colors.grayLight, borderRadius: 14, padding: 14 },
  line: { flexDirection: "row", justifyContent: "space-between", marginVertical: 3 },
  total: { fontFamily: fonts.priceBold, fontWeight: "800", fontSize: 17, color: colors.primary },
});
