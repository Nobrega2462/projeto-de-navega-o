import React from "react";
import { fonts } from "../theme";
import { ScrollView, View, StyleSheet } from "react-native";
import Text from "../components/Text";
import { MaterialIcons } from "@expo/vector-icons";
import { useThemed } from "../context/ThemeContext";

export default function About() {
  const { colors, styles } = useThemed(makeStyles);
  const tech = ["React Native 0.81", "Expo SDK 54", "React Navigation 7 (Drawer, Bottom Tabs, Stack)", "Context API + Hooks", "@expo/vector-icons (MaterialIcons)"];
  return (
    <ScrollView style={{ backgroundColor: "transparent" }} contentContainerStyle={{ padding: 20, alignItems: "center" }}>
      <View style={styles.logo}><MaterialIcons name="storefront" size={52} color={colors.white} /></View>
      <Text style={styles.name}>Vitrine Store</Text>
      <Text style={styles.ver}>Versão 1.0.0</Text>
      <Text style={styles.p}>Loja virtual de roupas, tênis e acessórios criada para demonstrar a navegação em React Native: Drawer → Bottom Tabs → Stack.</Text>
      <View style={styles.box}>
        <Text style={styles.h}>Tecnologias</Text>
        {tech.map((t) => <Text key={t} style={styles.li}>• {t}</Text>)}
      </View>
      <View style={[styles.box, { backgroundColor: colors.primaryLight }]}>
        <Text style={styles.h}>Projeto acadêmico</Text>
        <Text style={styles.li}>Desenvolvido para a disciplina de desenvolvimento mobile do curso de Análise e Desenvolvimento de Sistemas. Os produtos, pedidos e pagamentos são fictícios.</Text>
      </View>
    </ScrollView>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  logo: { width: 96, height: 96, borderRadius: 28, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" },
  name: { fontFamily: fonts.brand, fontSize: 26, fontWeight: "800", marginTop: 12, color: colors.text },
  ver: { color: colors.textSoft, marginBottom: 12 },
  p: { textAlign: "center", color: colors.textSoft, lineHeight: 22, marginBottom: 16 },
  box: { alignSelf: "stretch", backgroundColor: colors.grayLight, borderRadius: 14, padding: 16, marginBottom: 12 },
  h: { fontFamily: fonts.heading, fontWeight: "800", fontSize: 16, marginBottom: 6, color: colors.text },
  li: { color: colors.textSoft, lineHeight: 22 },
});
