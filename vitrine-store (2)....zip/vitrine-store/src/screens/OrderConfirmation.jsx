import React from "react";
import { fonts } from "../theme";
import { ScrollView, View, StyleSheet } from "react-native";
import Text from "../components/Text";
import { MaterialIcons } from "@expo/vector-icons";
import PrimaryButton from "../components/PrimaryButton";
import { formatPrice } from "../theme";
import { useThemed } from "../context/ThemeContext";

export default function OrderConfirmation({ route, navigation }) {
  const { colors, styles } = useThemed(makeStyles);
  const { order } = route.params; // pedido enviado pelo checkout via replace()

  const backToStore = () => {
    navigation.popToTop(); // volta o Stack do carrinho para a primeira tela
    navigation.navigate("homeTab"); // e troca para a aba Início
  };

  return (
    <ScrollView style={{ backgroundColor: "transparent" }} contentContainerStyle={{ padding: 20, alignItems: "center" }}>
      <MaterialIcons name="check-circle" size={84} color={colors.success} />
      <Text style={styles.title}>Pedido realizado com sucesso!</Text>
      <Text style={styles.sub}>Obrigado, {order.customer.name.split(" ")[0]}. Este é um pedido demonstrativo.</Text>
      <View style={styles.idBox}><Text style={styles.id}>Pedido {order.id}</Text></View>

      <View style={styles.box}>
        {order.items.map((i) => (
          <View key={i.id} style={styles.line}>
            <Text style={{ flex: 1, color: colors.text }}>{i.qty}x {i.name}</Text>
            <Text style={{ fontWeight: "700", color: colors.text }}>{formatPrice(i.unit * i.qty)}</Text>
          </View>
        ))}
        <View style={styles.line}><Text style={{ color: colors.text }}>Frete</Text><Text style={{ color: colors.text }}>{order.shipping === 0 ? "Grátis" : formatPrice(order.shipping)}</Text></View>
        <View style={styles.line}><Text style={{ color: colors.text }}>Pagamento</Text><Text style={{ color: colors.text }}>{order.payment}</Text></View>
        <View style={styles.line}><Text style={styles.total}>Total</Text><Text style={styles.total}>{formatPrice(order.total)}</Text></View>
      </View>
      <Text style={styles.addr}>Entrega em: {order.customer.address}, {order.customer.number} — CEP {order.customer.cep}</Text>

      <PrimaryButton title="Voltar à loja" icon="storefront" onPress={backToStore} style={{ alignSelf: "stretch", marginTop: 20 }} />
    </ScrollView>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  title: { fontFamily: fonts.heading, fontSize: 22, fontWeight: "800", color: colors.text, textAlign: "center", marginTop: 10 },
  sub: { color: colors.textSoft, textAlign: "center", marginTop: 4 },
  idBox: { backgroundColor: colors.primaryLight, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 8, marginVertical: 16 },
  id: { fontFamily: fonts.monoBold, color: colors.primary, fontWeight: "800", fontSize: 16 },
  box: { alignSelf: "stretch", backgroundColor: colors.grayLight, borderRadius: 14, padding: 14 },
  line: { flexDirection: "row", justifyContent: "space-between", marginVertical: 3 },
  total: { fontFamily: fonts.priceBold, fontWeight: "800", fontSize: 17, color: colors.primary },
  addr: { color: colors.textSoft, marginTop: 14, textAlign: "center" },
});
