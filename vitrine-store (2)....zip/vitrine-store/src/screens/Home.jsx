import React from "react";
import { fonts } from "../theme";
import { ScrollView, View, Pressable, FlatList, StyleSheet, useWindowDimensions } from "react-native";
import Text from "../components/Text";
import { MaterialIcons } from "@expo/vector-icons";
import ProductCard from "../components/ProductCard";
import Title from "../components/Title";
import PrimaryButton from "../components/PrimaryButton";
import FadeIn from "../components/FadeIn";
import PressableScale from "../components/PressableScale";
import { useStore } from "../context/StoreContext";
import { categories } from "../data/products";
import { useThemed } from "../context/ThemeContext";

export default function Home({ navigation }) {
  const { colors, styles } = useThemed(makeStyles);
  const { products, profile, favorites } = useStore();
  const { width } = useWindowDimensions();
  const featured = products.filter((p) => p.featured);
  const best = products.filter((p) => p.bestSeller);
  const cardW = Math.min(180, width * 0.45);

  // Navegação aninhada: Home (Stack) → aba "productsTab" → tela "products" com parâmetro
  const goCategory = (category) =>
    navigation.navigate("productsTab", { screen: "products", params: { category, ts: Date.now() } });

  return (
    <ScrollView style={styles.page} contentContainerStyle={{ padding: 16, paddingBottom: 32 }}>
      <FadeIn>
      <Text style={styles.hello}>Olá, {profile.name.split(" ")[0]}! 👋</Text>
      <Text style={styles.sub}>Encontre os melhores looks da estação.</Text>
      </FadeIn>

      {/* Banner promocional */}
      <FadeIn delay={120}>
      <View style={styles.banner}>
        <View style={{ flex: 1 }}>
          <Text style={styles.bannerTag}>OFERTAS DA SEMANA</Text>
          <Text style={styles.bannerTitle}>Até 25% OFF em produtos selecionados</Text>
          <PrimaryButton
            title="Ver ofertas"
            variant="outline"
            onPress={() => navigation.navigate("productsTab", { screen: "products", params: { category: "Todos", ts: Date.now() } })}
            style={{ alignSelf: "flex-start", marginTop: 6 }}
          />
        </View>
        <MaterialIcons name="local-offer" size={72} color="#C4B5FD" />
      </View>
      </FadeIn>

      {/* Indicador de favoritos */}
      <FadeIn delay={220}>
      <PressableScale style={styles.favRow} onPress={() => navigation.navigate("favoritesTab")}>
        <MaterialIcons name="favorite" size={20} color={colors.danger} />
        <Text style={styles.favText}>
          {favorites.length === 0 ? "Você ainda não tem favoritos" : `${favorites.length} produto(s) favoritado(s)`}
        </Text>
        <MaterialIcons name="chevron-right" size={22} color={colors.gray} />
      </PressableScale>
      </FadeIn>

      <FadeIn delay={300}>
      <Title title="Categorias" />
      <View style={styles.cats}>
        {categories.map((c) => (
          <PressableScale key={c.name} outerStyle={styles.cat} onPress={() => goCategory(c.name)}>
            <View style={styles.catIcon}><MaterialIcons name={c.icon} size={26} color={colors.primary} /></View>
            <Text style={styles.catText}>{c.name}</Text>
          </PressableScale>
        ))}
      </View>
      </FadeIn>

      <FadeIn delay={380}>
      <Title title="Em destaque" subtitle="Selecionados para você" />
      <FlatList
        horizontal
        data={featured}
        keyExtractor={(p) => String(p.id)}
        showsHorizontalScrollIndicator={false}
        renderItem={({ item }) => <ProductCard product={item} width={cardW} />}
      />

      </FadeIn>

      <FadeIn delay={460}>
      <Title title="Mais vendidos" subtitle="Os queridinhos da loja" />
      <FlatList
        horizontal
        data={best}
        keyExtractor={(p) => String(p.id)}
        showsHorizontalScrollIndicator={false}
        renderItem={({ item }) => <ProductCard product={item} width={cardW} />}
      />

      </FadeIn>

      <PrimaryButton title="Ver todos os produtos" icon="storefront" style={{ marginTop: 20 }}
        onPress={() => navigation.navigate("productsTab", { screen: "products", params: { category: "Todos", ts: Date.now() } })} />
    </ScrollView>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  page: { flex: 1 },
  hello: { fontFamily: fonts.heading, fontSize: 22, fontWeight: "800", color: colors.text },
  sub: { color: colors.textSoft, marginBottom: 14 },
  banner: { backgroundColor: colors.primary, borderRadius: 20, padding: 18, flexDirection: "row", alignItems: "center" },
  bannerTag: { color: "#DDD6FE", fontSize: 12, fontWeight: "700", letterSpacing: 1 },
  bannerTitle: { fontFamily: fonts.heading, color: colors.white, fontSize: 20, fontWeight: "800", marginVertical: 6 },
  favRow: { flexDirection: "row", alignItems: "center", backgroundColor: colors.grayLight, padding: 12, borderRadius: 12, marginTop: 14 },
  favText: { flex: 1, marginLeft: 8, color: colors.text },
  cats: { flexDirection: "row", justifyContent: "space-between" },
  cat: { flex: 1, alignItems: "center" },
  catIcon: { width: 58, height: 58, borderRadius: 18, backgroundColor: colors.primaryLight, alignItems: "center", justifyContent: "center" },
  catText: { fontSize: 12, marginTop: 6, color: colors.text, fontWeight: "600" },
});
