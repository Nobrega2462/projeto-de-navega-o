import React from "react";
import { fonts } from "../theme";
import { ScrollView, View, Switch, StyleSheet } from "react-native";
import Text from "../components/Text";
import { MaterialIcons } from "@expo/vector-icons";
import { useStore } from "../context/StoreContext";
import { useThemed, useTheme } from "../context/ThemeContext";

export default function Settings() {
  const { colors, styles } = useThemed(makeStyles);
  const { settings, setSettings } = useStore();
  const { dark, toggleTheme } = useTheme();
  const toggle = (k) => (v) => setSettings((s) => ({ ...s, [k]: v }));

  const options = [
    { k: "notifications", icon: "notifications", title: "Notificações", desc: "Avisos sobre pedidos e promoções" },
    { k: "offers", icon: "email", title: "Ofertas por e-mail", desc: "Receber novidades semanais" },
    { k: "installments", icon: "credit-card", title: "Mostrar parcelamento", desc: "Exibe “ou 10x de ...” nos cartões de produto" },
  ];

  return (
    <ScrollView style={{ backgroundColor: "transparent" }} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.h}>Aparência</Text>
      <View style={styles.row}>
        <View style={styles.icon}><MaterialIcons name={dark ? "dark-mode" : "light-mode"} size={22} color={colors.primary} /></View>
        <View style={{ flex: 1 }}>
          <Text style={styles.t}>Modo escuro</Text>
          <Text style={styles.d}>{dark ? "Tema escuro ativado" : "Tema claro ativado"}</Text>
        </View>
        <Switch value={dark} onValueChange={toggleTheme} trackColor={{ true: colors.primary, false: colors.border }} thumbColor={colors.white} />
      </View>
      <Text style={[styles.h, { marginTop: 14 }]}>Preferências</Text>
      {options.map((o) => (
        <View key={o.k} style={styles.row}>
          <View style={styles.icon}><MaterialIcons name={o.icon} size={22} color={colors.primary} /></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.t}>{o.title}</Text>
            <Text style={styles.d}>{o.desc}</Text>
          </View>
          <Switch value={settings[o.k]} onValueChange={toggle(o.k)} trackColor={{ true: colors.primary, false: colors.border }} thumbColor={colors.white} />
        </View>
      ))}
      <Text style={styles.note}>Teste: desligue “Mostrar parcelamento” e volte à loja — os cartões mudam na hora.</Text>
    </ScrollView>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  h: { fontFamily: fonts.heading, fontSize: 18, fontWeight: "800", marginBottom: 10, color: colors.text },
  row: { flexDirection: "row", alignItems: "center", backgroundColor: colors.grayLight, borderRadius: 14, padding: 12, marginBottom: 10 },
  icon: { width: 40, height: 40, borderRadius: 12, backgroundColor: colors.primaryLight, alignItems: "center", justifyContent: "center", marginRight: 12 },
  t: { fontWeight: "700", color: colors.text },
  d: { fontSize: 12, color: colors.textSoft },
  note: { marginTop: 10, fontSize: 12, color: colors.textSoft },
});
