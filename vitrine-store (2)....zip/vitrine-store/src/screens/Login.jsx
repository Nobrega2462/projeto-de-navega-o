import React, { useState } from "react";
import { View, Animated, Pressable } from "react-native";
import Text from "../components/Text";
import AuthLayout from "../components/AuthLayout";
import AuthInput from "../components/AuthInput";
import PrimaryButton from "../components/PrimaryButton";
import useShake from "../components/useShake";
import { useAuth, isValidEmail } from "../context/AuthContext";
import { useTheme } from "../context/ThemeContext";

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

export default function Login({ navigation }) {
  const { colors } = useTheme();
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [shakeStyle, shake] = useShake();

  const submit = async () => {
    const e = {};
    if (!isValidEmail(email)) e.email = "Informe um e-mail válido";
    if (password.length < 6) e.password = "A senha tem no mínimo 6 caracteres";
    setErrors(e);
    if (Object.keys(e).length) return shake();

    setLoading(true);
    await wait(700); // simula a consulta ao servidor
    const r = login(email, password);
    setLoading(false);
    if (r.needsVerification) navigation.navigate("verifyEmail", { email: r.email });
    else if (!r.ok) { setErrors({ form: r.error }); shake(); }
    // se deu certo, o AuthContext define o usuário e o app troca para a loja
  };

  return (
    <AuthLayout title="Bem-vindo de volta 👋" subtitle="Entre na sua conta para continuar comprando.">
      <Animated.View style={shakeStyle}>
        <AuthInput label="E-mail" icon="mail-outline" placeholder="voce@email.com" keyboardType="email-address" value={email} onChangeText={setEmail} error={errors.email} />
        <AuthInput label="Senha" icon="lock-outline" placeholder="Sua senha" secure value={password} onChangeText={setPassword} error={errors.password} />
        {errors.form ? <Text style={{ color: colors.danger, marginBottom: 8 }}>{errors.form}</Text> : null}
      </Animated.View>
      <PrimaryButton title="Entrar" icon="login" onPress={submit} loading={loading} style={{ marginTop: 6 }} />
      <PrimaryButton title="Criar conta" variant="outline" onPress={() => navigation.navigate("register")} style={{ marginTop: 12 }} />
      <Pressable onPress={() => { setEmail("demo@vitrine.com"); setPassword("123456"); setErrors({}); }} style={{ marginTop: 18, alignItems: "center" }}>
        <View style={{ backgroundColor: colors.primaryLight, borderRadius: 12, padding: 10 }}>
          <Text style={{ color: colors.primary, fontWeight: "600", textAlign: "center" }}>Toque aqui para preencher a conta de teste (demo@vitrine.com / 123456)</Text>
        </View>
      </Pressable>
    </AuthLayout>
  );
}
