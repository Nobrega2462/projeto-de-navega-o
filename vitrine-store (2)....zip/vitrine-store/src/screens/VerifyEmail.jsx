import React, { useEffect, useState } from "react";
import { Animated, Pressable } from "react-native";
import Text from "../components/Text";
import AuthLayout from "../components/AuthLayout";
import AuthInput from "../components/AuthInput";
import PrimaryButton from "../components/PrimaryButton";
import useShake from "../components/useShake";
import { useAuth } from "../context/AuthContext";
import { useTheme } from "../context/ThemeContext";

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

export default function VerifyEmail({ route, navigation }) {
  const { colors } = useTheme();
  const { email } = route.params; // recebido de Login/Register
  const { verifyEmail, resendCode } = useAuth();
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [cooldown, setCooldown] = useState(30); // segundos até poder reenviar
  const [shakeStyle, shake] = useShake();

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  const submit = async () => {
    if (code.length !== 6) { setError("Digite os 6 dígitos do código."); return shake(); }
    setLoading(true);
    await wait(600);
    const r = verifyEmail(email, code);
    setLoading(false);
    if (!r.ok) { setError(r.error); shake(); }
    // se ok, o usuário é autenticado e o app entra na loja automaticamente
  };

  const resend = () => { resendCode(email); setCode(""); setError(""); setCooldown(30); };

  return (
    <AuthLayout title="Verifique seu e-mail" subtitle={`Enviamos um código de 6 dígitos para ${email}. Ele vale por 10 minutos.`} onBack={() => navigation.goBack()}>
      <Animated.View style={shakeStyle}>
        <AuthInput mono label="Código de verificação" icon="pin" placeholder="000000" keyboardType="number-pad" maxLength={6}
          value={code} onChangeText={(t) => setCode(t.replace(/\D/g, ""))} error={error} />
      </Animated.View>
      <PrimaryButton title="Verificar e entrar" icon="verified" onPress={submit} loading={loading} style={{ marginTop: 6 }} />
      <Pressable disabled={cooldown > 0} onPress={resend} style={{ marginTop: 18, alignItems: "center" }}>
        <Text style={{ color: cooldown > 0 ? colors.gray : colors.primary, fontWeight: "700" }}>
          {cooldown > 0 ? `Reenviar código em ${cooldown}s` : "Reenviar código"}
        </Text>
      </Pressable>
    </AuthLayout>
  );
}
