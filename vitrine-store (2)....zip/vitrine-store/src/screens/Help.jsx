import React, { useState } from "react";
import { fonts } from "../theme";
import { ScrollView, View, Pressable, StyleSheet } from "react-native";
import Text from "../components/Text";
import { MaterialIcons } from "@expo/vector-icons";
import { useThemed } from "../context/ThemeContext";

const FAQ = [
  { q: "Como adiciono um produto ao carrinho?", a: "Abra o produto, escolha a quantidade e toque em “Adicionar ao carrinho”." },
  { q: "Como favorito um produto?", a: "Toque no coração no cartão ou na tela de detalhes. Veja todos na aba Favoritos." },
  { q: "Qual o valor do frete?", a: "O frete demonstrativo é R$ 19,90 e é grátis em compras acima de R$ 299,00." },
  { q: "Como acompanho meu pedido?", a: "Após confirmar, você recebe o número do pedido na tela de confirmação (demonstrativo)." },
  { q: "Os pagamentos são reais?", a: "Não. Este é um projeto acadêmico e nenhuma transação é processada." },
];

export default function Help() {
  const { colors, styles } = useThemed(makeStyles);
  const [open, setOpen] = useState(null);
  return (
    <ScrollView style={{ backgroundColor: "transparent" }} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.h}>Perguntas frequentes</Text>
      {FAQ.map((f, i) => (
        <Pressable key={i} style={styles.card} onPress={() => setOpen(open === i ? null : i)}>
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <Text style={styles.q}>{f.q}</Text>
            <MaterialIcons name={open === i ? "expand-less" : "expand-more"} size={24} color={colors.primary} />
          </View>
          {open === i && <Text style={styles.a}>{f.a}</Text>}
        </Pressable>
      ))}
      <Text style={styles.h}>Como usar o app</Text>
      <Text style={styles.a}>• Use as abas inferiores para navegar.{"\n"}• Abra o menu ☰ para Perfil, Configurações, Ajuda e Sobre.{"\n"}• No carrinho, toque em “Finalizar compra” para concluir.</Text>
    </ScrollView>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  h: { fontFamily: fonts.heading, fontSize: 18, fontWeight: "800", marginVertical: 10, color: colors.text },
  card: { backgroundColor: colors.grayLight, borderRadius: 14, padding: 14, marginBottom: 8 },
  q: { flex: 1, fontWeight: "700", color: colors.text },
  a: { color: colors.textSoft, marginTop: 8, lineHeight: 21 },
});
