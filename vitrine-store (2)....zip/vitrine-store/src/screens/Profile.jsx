import React, { useState } from "react";
import { fonts } from "../theme";
import { ScrollView, View, TextInput, StyleSheet } from "react-native";
import Text from "../components/Text";
import { MaterialIcons } from "@expo/vector-icons";
import PrimaryButton from "../components/PrimaryButton";
import { useStore } from "../context/StoreContext";
import { useAuth } from "../context/AuthContext";
import { useThemed } from "../context/ThemeContext";

// Perfil demonstrativo, editável apenas durante a sessão (sem autenticação real)
export default function Profile() {
  const { colors, styles } = useThemed(makeStyles);
  const { profile, setProfile, favorites, totalItems } = useStore();
  const { logout } = useAuth();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(profile);

  const save = () => { setProfile(draft); setEditing(false); };
  const labels = { name: "Nome", email: "E-mail", phone: "Telefone", city: "Cidade" };

  return (
    <ScrollView style={{ backgroundColor: "transparent" }} contentContainerStyle={{ padding: 20 }}>
      <View style={{ alignItems: "center", marginBottom: 20 }}>
        <View style={styles.avatar}><MaterialIcons name="person" size={56} color={colors.primary} /></View>
        <Text style={styles.name}>{profile.name}</Text>
        <Text style={{ color: colors.textSoft }}>{profile.email}</Text>
      </View>
      <View style={styles.stats}>
        <Stat n={favorites.length} l="Favoritos" />
        <Stat n={totalItems} l="No carrinho" />
      </View>
      {Object.keys(labels).map((k) => (
        <View key={k} style={{ marginBottom: 12 }}>
          <Text style={styles.label}>{labels[k]}</Text>
          {editing ? (
            <TextInput placeholderTextColor={colors.gray} style={styles.input} value={draft[k]} onChangeText={(v) => setDraft({ ...draft, [k]: v })} />
          ) : (
            <Text style={styles.value}>{profile[k]}</Text>
          )}
        </View>
      ))}
      {editing ? (
        <PrimaryButton title="Salvar" icon="save" onPress={save} />
      ) : (
        <PrimaryButton title="Editar perfil" icon="edit" variant="outline" onPress={() => { setDraft(profile); setEditing(true); }} />
      )}
      <PrimaryButton title="Sair da conta" icon="logout" onPress={logout} style={{ marginTop: 12 }} />
    </ScrollView>
  );
}
function Stat({ n, l }) {
  const { colors, styles } = useThemed(makeStyles);
  return (
    <View style={styles.stat}><Text style={styles.statN}>{n}</Text><Text style={{ color: colors.textSoft }}>{l}</Text></View>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  avatar: { width: 100, height: 100, borderRadius: 50, backgroundColor: colors.primaryLight, alignItems: "center", justifyContent: "center" },
  name: { fontFamily: fonts.heading, fontSize: 22, fontWeight: "800", marginTop: 10, color: colors.text },
  stats: { flexDirection: "row", gap: 12, marginBottom: 20 },
  stat: { flex: 1, backgroundColor: colors.grayLight, borderRadius: 14, padding: 14, alignItems: "center" },
  statN: { fontFamily: fonts.price, fontSize: 24, fontWeight: "800", color: colors.primary },
  label: { fontSize: 13, color: colors.textSoft, marginBottom: 4 },
  value: { fontSize: 16, color: colors.text, fontWeight: "600" },
  input: { fontFamily: fonts.body, color: colors.text, borderWidth: 1, borderColor: colors.border, borderRadius: 12, padding: 11, backgroundColor: colors.grayLight },
});
