import React from "react";
import { FlatList, useWindowDimensions } from "react-native";
import ProductCard from "../components/ProductCard";
import EmptyState from "../components/EmptyState";
import FadeIn from "../components/FadeIn";
import { useStore } from "../context/StoreContext";
import { useTheme } from "../context/ThemeContext";

export default function Favorites({ navigation }) {
  const { colors } = useTheme();
  const { products, favorites } = useStore();
  const { width } = useWindowDimensions();
  const cols = width >= 900 ? 4 : width >= 600 ? 3 : 2;
  const cardW = (width - 20) / cols - 12;
  // Mesmo estado global usado no card e nos detalhes: remover aqui some da lista na hora
  const list = products.filter((p) => favorites.includes(p.id));

  return (
    <FlatList
      key={cols}
      style={{ backgroundColor: "transparent" }}
      data={list}
      numColumns={cols}
      keyExtractor={(p) => String(p.id)}
      contentContainerStyle={{ padding: 10, flexGrow: 1 }}
      renderItem={({ item, index }) => (
        <FadeIn delay={Math.min(index, 8) * 60}><ProductCard product={item} width={cardW} /></FadeIn>
      )}
      ListEmptyComponent={
        <EmptyState icon="favorite-border" title="Nenhum favorito ainda" message="Toque no coração de um produto para salvá-lo aqui."
          buttonTitle="Explorar produtos" onPress={() => navigation.navigate("productsTab", { screen: "products" })} />
      }
    />
  );
}
