import React, { useState } from "react";
import { Animated } from "react-native";
import AuthLayout from "../components/AuthLayout";
import AuthInput from "../components/AuthInput";
import PrimaryButton from "../components/PrimaryButton";
import useShake from "../components/useShake";
import { useAuth, isValidEmail } from "../context/AuthContext";

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

export default function Register({ navigation }) {
  const { register } = useAuth();
  const [form, setForm] = useState({ name: "", email: "", password: "", confirm: "" });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [shakeStyle, shake] = useShake();
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async () => {
    const e = {};
    if (form.name.trim().length < 3) e.name = "Informe seu nome completo";
    if (!isValidEmail(form.email)) e.email = "Informe um e-mail válido";
    if (form.password.length < 6) e.password = "A senha tem no mínimo 6 caracteres";
    if (form.confirm !== form.password) e.confirm = "As senhas não coincidem";
    setErrors(e);
    if (Object.keys(e).length) return shake();

    setLoading(true);
    await wait(700);
    const r = register(form.name, form.email, form.password);
    setLoading(false);
    if (!r.ok) { setErrors({ email: r.error }); return shake(); }
    // Vai para a verificação, enviando o e-mail como parâmetro de rota
    navigation.navigate("verifyEmail", { email: r.email });
  };

  return (
    <AuthLayout title="Criar conta" subtitle="Enviaremos um código de verificação para o seu e-mail." onBack={() => navigation.goBack()}>
      <Animated.View style={shakeStyle}>
        <AuthInput label="Nome completo" icon="person-outline" placeholder="Seu nome" autoCapitalize="words" value={form.name} onChangeText={set("name")} error={errors.name} />
        <AuthInput label="E-mail" icon="mail-outline" placeholder="voce@email.com" keyboardType="email-address" value={form.email} onChangeText={set("email")} error={errors.email} />
        <AuthInput label="Senha" icon="lock-outline" placeholder="Mínimo 6 caracteres" secure value={form.password} onChangeText={set("password")} error={errors.password} />
        <AuthInput label="Confirmar senha" icon="lock-outline" placeholder="Repita a senha" secure value={form.confirm} onChangeText={set("confirm")} error={errors.confirm} />
      </Animated.View>
      <PrimaryButton title="Cadastrar e verificar e-mail" icon="mark-email-read" onPress={submit} loading={loading} style={{ marginTop: 6 }} />
    </AuthLayout>
  );
}
