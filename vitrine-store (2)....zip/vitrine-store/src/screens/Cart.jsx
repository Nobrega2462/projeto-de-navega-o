import React from "react";
import { fonts } from "../theme";
import { View, FlatList, StyleSheet } from "react-native";
import Text from "../components/Text";
import ButtonIcon from "../components/ButtonIcon";
import PrimaryButton from "../components/PrimaryButton";
import ProductImage from "../components/ProductImage";
import EmptyState from "../components/EmptyState";
import FadeIn from "../components/FadeIn";
import { useStore } from "../context/StoreContext";
import { formatPrice } from "../theme";
import { useThemed } from "../context/ThemeContext";

export default function Cart({ navigation }) {
  const { colors, styles } = useThemed(makeStyles);
  const { items, increaseQty, decreaseQty, removeFromCart, clearCart, subtotal, shipping, discount, total, freeShippingFrom } = useStore();

  if (items.length === 0) {
    return (
      <View style={{ flex: 1 }}>
        <EmptyState icon="shopping-cart" title="Seu carrinho está vazio" message="Adicione produtos para vê-los aqui."
          buttonTitle="Voltar à loja" onPress={() => navigation.navigate("homeTab")} />
      </View>
    );
  }

  return (
    <View style={styles.page}>
      <FlatList
        data={items}
        keyExtractor={(i) => String(i.id)}
        contentContainerStyle={{ padding: 14 }}
        renderItem={({ item, index }) => (
          <FadeIn delay={Math.min(index, 6) * 70} style={styles.item}>
            <ProductImage uri={item.image} style={styles.img} />
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={styles.name} numberOfLines={2}>{item.name}</Text>
              <Text style={styles.unit}>{formatPrice(item.unit)} cada</Text>
              <View style={styles.qtyRow}>
                <ButtonIcon name="remove" size={20} background={colors.primaryLight} color={colors.primary} label="Diminuir" onPress={() => decreaseQty(item.id)} />
                <Text style={styles.qty}>{item.qty}</Text>
                <ButtonIcon name="add" size={20} background={colors.primaryLight} color={colors.primary} label="Aumentar" onPress={() => increaseQty(item.id)} />
              </View>
            </View>
            <View style={{ alignItems: "flex-end", justifyContent: "space-between" }}>
              <ButtonIcon name="delete-outline" color={colors.danger} label="Remover" onPress={() => removeFromCart(item.id)} />
              <Text style={styles.line}>{formatPrice(item.lineTotal)}</Text>
            </View>
          </FadeIn>
        )}
        ListFooterComponent={
          <FadeIn delay={200} style={styles.summary}>
            <Row label="Subtotal" value={formatPrice(subtotal)} />
            <Row label="Frete" value={shipping === 0 ? "Grátis" : formatPrice(shipping)} />
            {discount > 0 && <Row label="Você economiza" value={`- ${formatPrice(discount)}`} color={colors.success} />}
            <Text style={styles.hint}>Frete grátis em compras acima de {formatPrice(freeShippingFrom)}</Text>
            <View style={styles.sep} />
            <Row label="Total" value={formatPrice(total)} big />
            <PrimaryButton title="Finalizar compra" icon="lock" style={{ marginTop: 14 }} onPress={() => navigation.navigate("checkout")} />
            <PrimaryButton title="Continuar comprando" variant="outline" style={{ marginTop: 10 }} onPress={() => navigation.navigate("productsTab", { screen: "products" })} />
            <PrimaryButton title="Limpar carrinho" variant="outline" style={{ marginTop: 10 }} onPress={clearCart} />
          </FadeIn>
        }
      />
    </View>
  );
}

function Row({ label, value, big, color }) {
  const { colors, styles } = useThemed(makeStyles);
  return (
    <View style={styles.row}>
      <Text style={[styles.rowL, big && { fontWeight: "800", fontSize: 18, color: colors.text }]}>{label}</Text>
      <Text style={[styles.rowV, big && { fontSize: 20, color: colors.primary }, color && { color }]}>{value}</Text>
    </View>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  page: { flex: 1 },
  item: { flexDirection: "row", backgroundColor: colors.surface, borderRadius: 16, padding: 10, marginBottom: 10 },
  img: { width: 84, height: 84, borderRadius: 12 },
  name: { fontWeight: "700", color: colors.text },
  unit: { color: colors.textSoft, fontSize: 12, marginTop: 2 },
  qtyRow: { flexDirection: "row", alignItems: "center", marginTop: 6 },
  qty: { fontFamily: fonts.price, color: colors.text, minWidth: 34, textAlign: "center", fontWeight: "800", fontSize: 16 },
  line: { fontFamily: fonts.price, fontWeight: "800", color: colors.primary },
  summary: { backgroundColor: colors.surface, borderRadius: 16, padding: 16, marginTop: 4, marginBottom: 24 },
  row: { flexDirection: "row", justifyContent: "space-between", marginVertical: 4 },
  rowL: { color: colors.textSoft },
  rowV: { fontFamily: fonts.price, fontWeight: "700", color: colors.text },
  hint: { fontSize: 12, color: colors.textSoft, marginTop: 4 },
  sep: { height: 1, backgroundColor: colors.border, marginVertical: 10 },
});
