import React, { useState } from "react";
import { fonts } from "../theme";
import { ScrollView, View, StyleSheet } from "react-native";
import Text from "../components/Text";
import { useRoute } from "@react-navigation/native";
import { MaterialIcons } from "@expo/vector-icons";
import ButtonIcon from "../components/ButtonIcon";
import FadeIn from "../components/FadeIn";
import HeartButton from "../components/HeartButton";
import PrimaryButton from "../components/PrimaryButton";
import ProductImage from "../components/ProductImage";
import EmptyState from "../components/EmptyState";
import { useStore } from "../context/StoreContext";
import { getProductById } from "../data/products";
import { formatPrice } from "../theme";
import { useThemed } from "../context/ThemeContext";

export default function ProductDetails({ navigation }) {
  const { colors, styles } = useThemed(makeStyles);
  // Lê o parâmetro enviado por navigation.navigate("productDetails", { productId })
  const { productId } = useRoute().params ?? {};
  const product = getProductById(productId);
  const { addToCart, isFavorite, toggleFavorite, cart } = useStore();
  const [qty, setQty] = useState(1);
  const [msg, setMsg] = useState(null);
  const [msgKey, setMsgKey] = useState(0);
  // flash: mostra a confirmação e reinicia a animação a cada nova mensagem
  const flash = (t) => { setMsg(t); setMsgKey((k) => k + 1); };

  if (!product) {
    return <EmptyState icon="error-outline" title="Produto não encontrado" buttonTitle="Voltar" onPress={() => navigation.goBack()} />;
  }

  const inCart = cart.find((i) => i.id === product.id)?.qty ?? 0;
  const available = product.stock - inCart; // quanto ainda pode ser adicionado
  const final = product.promoPrice ?? product.price;
  const fav = isFavorite(product.id);

  const changeQty = (d) => setQty((q) => Math.min(Math.max(1, q + d), Math.max(1, available)));

  const add = () => {
    if (addToCart(product.id, qty)) {
      flash(`${qty} item(ns) adicionado(s) ao carrinho!`);
      setQty(1);
    } else {
      flash("Quantidade acima do estoque disponível.");
    }
  };

  return (
    <ScrollView style={{ backgroundColor: "transparent" }} contentContainerStyle={{ paddingBottom: 32 }}>
      <ProductImage uri={product.image} style={styles.img} />
      <View style={styles.body}>
        <View style={styles.row}>
          <Text style={styles.cat}>{product.category}</Text>
          <HeartButton active={fav} size={26} background={colors.grayLight} onPress={() => toggleFavorite(product.id)} />
        </View>
        <Text style={styles.name}>{product.name}</Text>
        {product.promoPrice ? <Text style={styles.old}>{formatPrice(product.price)}</Text> : null}
        <Text style={styles.price}>{formatPrice(final)}</Text>
        <Text style={[styles.stock, { color: available > 0 ? colors.success : colors.danger }]}>
          {available > 0 ? `${product.stock} em estoque` : "Todo o estoque já está no seu carrinho"}
        </Text>

        <Text style={styles.h}>Descrição</Text>
        <Text style={styles.desc}>{product.description}</Text>

        <Text style={styles.h}>Quantidade</Text>
        <View style={styles.qtyRow}>
          <ButtonIcon name="remove" background={colors.primaryLight} color={colors.primary} label="Diminuir" onPress={() => changeQty(-1)} />
          <Text style={styles.qty}>{qty}</Text>
          <ButtonIcon name="add" background={colors.primaryLight} color={colors.primary} label="Aumentar" onPress={() => changeQty(1)} />
        </View>

        <PrimaryButton title="Adicionar ao carrinho" icon="add-shopping-cart" disabled={available <= 0} onPress={add} style={{ marginTop: 20 }} />
        {msg && (
          <FadeIn key={msgKey} from={10} duration={300} style={styles.msg}>
            <MaterialIcons name="check-circle" size={20} color={colors.success} />
            <Text style={{ marginLeft: 8, flex: 1, color: colors.text }}>{msg}</Text>
          </FadeIn>
        )}
        {inCart > 0 && (
          <PrimaryButton title="Ir para o carrinho" variant="outline" style={{ marginTop: 12 }}
            onPress={() => navigation.navigate("cartTab", { screen: "cart" })} />
        )}
        <PrimaryButton title="Voltar" variant="outline" style={{ marginTop: 12 }} onPress={() => navigation.goBack()} />
      </View>
    </ScrollView>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  img: { width: "100%", height: 320 },
  body: { padding: 18 },
  row: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  cat: { color: colors.primary, fontWeight: "700", backgroundColor: colors.primaryLight, paddingHorizontal: 12, paddingVertical: 4, borderRadius: 12, overflow: "hidden" },
  name: { fontFamily: fonts.heading, fontSize: 22, fontWeight: "800", color: colors.text, marginTop: 10 },
  old: { fontFamily: fonts.price, color: colors.gray, textDecorationLine: "line-through", marginTop: 6 },
  price: { fontFamily: fonts.priceBold, fontSize: 28, fontWeight: "800", color: colors.primary },
  stock: { fontWeight: "600", marginTop: 4 },
  h: { fontFamily: fonts.heading, fontSize: 16, fontWeight: "700", marginTop: 18, marginBottom: 6, color: colors.text },
  desc: { color: colors.textSoft, lineHeight: 22 },
  qtyRow: { flexDirection: "row", alignItems: "center" },
  qty: { fontFamily: fonts.price, color: colors.text, fontSize: 20, fontWeight: "800", minWidth: 50, textAlign: "center" },
  msg: { flexDirection: "row", alignItems: "center", backgroundColor: colors.successBg, padding: 12, borderRadius: 12, marginTop: 12 },
});
