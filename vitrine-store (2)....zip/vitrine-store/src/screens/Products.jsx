import React, { useEffect, useMemo, useState } from "react";
import { fonts } from "../theme";
import { View, TextInput, FlatList, Pressable, StyleSheet, useWindowDimensions } from "react-native";
import Text from "../components/Text";
import { MaterialIcons } from "@expo/vector-icons";
import ProductCard from "../components/ProductCard";
import EmptyState from "../components/EmptyState";
import FadeIn from "../components/FadeIn";
import PressableScale from "../components/PressableScale";
import { useStore } from "../context/StoreContext";
import { categories } from "../data/products";
import { useThemed } from "../context/ThemeContext";

const SORTS = [
  { key: "default", label: "Padrão" },
  { key: "asc", label: "Menor preço" },
  { key: "desc", label: "Maior preço" },
];

export default function Products({ route, navigation }) {
  const { colors, styles } = useThemed(makeStyles);
  const { products } = useStore();
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("Todos");
  const [sort, setSort] = useState("default");
  const { width } = useWindowDimensions();
  const cols = width >= 900 ? 4 : width >= 600 ? 3 : 2; // colunas responsivas
  const cardW = (width - 20) / cols - 12;

  // Recebe o filtro enviado pela Home (route.params.category)
  useEffect(() => {
    if (route.params?.category) setCategory(route.params.category);
  }, [route.params?.category, route.params?.ts]);

  // Busca + filtro + ordenação (recalculados a cada mudança)
  const list = useMemo(() => {
    let r = products.filter(
      (p) =>
        (category === "Todos" || p.category === category) &&
        p.name.toLowerCase().includes(search.trim().toLowerCase())
    );
    const price = (p) => p.promoPrice ?? p.price;
    if (sort === "asc") r = [...r].sort((a, b) => price(a) - price(b));
    if (sort === "desc") r = [...r].sort((a, b) => price(b) - price(a));
    return r;
  }, [products, search, category, sort]);

  const chips = ["Todos", ...categories.map((c) => c.name)];

  return (
    <View style={styles.page}>
      <View style={styles.searchBox}>
        <MaterialIcons name="search" size={22} color={colors.gray} />
        <TextInput placeholderTextColor={colors.gray} style={styles.input} placeholder="Buscar produto pelo nome" value={search} onChangeText={setSearch} />
        {search ? (
          <Pressable onPress={() => setSearch("")}><MaterialIcons name="close" size={20} color={colors.gray} /></Pressable>
        ) : null}
      </View>

      <View style={styles.chipRow}>
        {chips.map((c) => (
          <PressableScale key={c} onPress={() => setCategory(c)} style={[styles.chip, category === c && styles.chipOn]}>
            <Text style={[styles.chipText, category === c && { color: colors.white }]}>{c}</Text>
          </PressableScale>
        ))}
      </View>

      <View style={styles.sortRow}>
        <MaterialIcons name="sort" size={18} color={colors.textSoft} />
        {SORTS.map((s) => (
          <Pressable key={s.key} onPress={() => setSort(s.key)}>
            <Text style={[styles.sortText, sort === s.key && styles.sortOn]}>{s.label}</Text>
          </Pressable>
        ))}
      </View>

      <FlatList
        key={cols}
        data={list}
        numColumns={cols}
        keyExtractor={(p) => String(p.id)}
        contentContainerStyle={{ padding: 10, flexGrow: 1 }}
        renderItem={({ item, index }) => (
          <FadeIn delay={Math.min(index, 8) * 60}><ProductCard product={item} width={cardW} /></FadeIn>
        )}
        ListEmptyComponent={
          <EmptyState icon="search-off" title="Nenhum produto encontrado" message="Tente outro nome ou limpe os filtros."
            buttonTitle="Limpar filtros" onPress={() => { setSearch(""); setCategory("Todos"); setSort("default"); }} />
        }
      />
    </View>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  page: { flex: 1 },
  searchBox: { flexDirection: "row", alignItems: "center", backgroundColor: colors.grayLight, margin: 12, marginBottom: 6, paddingHorizontal: 12, borderRadius: 14 },
  input: { fontFamily: fonts.body, color: colors.text, flex: 1, paddingVertical: 12, paddingHorizontal: 8, fontSize: 15 },
  chipRow: { flexDirection: "row", flexWrap: "wrap", paddingHorizontal: 12, gap: 8 },
  chip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: colors.grayLight },
  chipOn: { backgroundColor: colors.primary },
  chipText: { fontWeight: "600", color: colors.text, fontSize: 13 },
  sortRow: { flexDirection: "row", alignItems: "center", gap: 14, paddingHorizontal: 14, paddingVertical: 10 },
  sortText: { color: colors.textSoft, fontSize: 13 },
  sortOn: { color: colors.primary, fontWeight: "800" },
});
