// Paletas de cores da Vitrine Store (claro e escuro) + formatação de preço.
// `white` é sempre branco (texto sobre fundo roxo). `surface` é o fundo de cartões/barras.
export const lightColors = {
  primary: "#7C3AED",
  primaryLight: "#EDE9FE",
  white: "#FFFFFF",
  surface: "#FFFFFF",
  background: "#FFFFFF",
  overlay: "rgba(255,255,255,0.80)", // véu sobre a foto de fundo (mantém tudo legível)
  gray: "#9CA3AF",
  grayLight: "#F3F4F6",
  border: "#E5E7EB",
  text: "#111827",
  textSoft: "#6B7280",
  danger: "#EF4444",
  success: "#10B981",
  successBg: "#ECFDF5",
};

export const darkColors = {
  primary: "#8B5CF6", // roxo um pouco mais claro para ter contraste no escuro
  primaryLight: "#2E2358",
  white: "#FFFFFF",
  surface: "#1C1930",
  background: "#0E0C18",
  overlay: "rgba(14,12,24,0.82)",
  gray: "#9CA3AF",
  grayLight: "#2A2644",
  border: "#3A3560",
  text: "#F3F4F6",
  textSoft: "#B4B2C8",
  danger: "#F87171",
  success: "#34D399",
  successBg: "#0F2F26",
};

// Formata preços no padrão brasileiro: R$ 1.129,90
export function formatPrice(value) {
  const [int, dec] = Number(value).toFixed(2).split(".");
  return `R$ ${int.replace(/\B(?=(\d{3})+(?!\d))/g, ".")},${dec}`;
}

// Fontes do app (carregadas em App.jsx). Cada tipo de conteúdo usa uma família diferente:
export const fonts = {
  brand: "Pacifico_400Regular",          // nome da loja (logo e cabeçalhos)
  heading: "PlayfairDisplay_700Bold",    // títulos e destaques
  body: "Poppins_400Regular",            // textos corridos
  bodyMedium: "Poppins_500Medium",
  bodySemi: "Poppins_600SemiBold",       // botões, rótulos, abas, menu
  bodyBold: "Poppins_700Bold",
  price: "Montserrat_700Bold",           // preços e números
  priceBold: "Montserrat_800ExtraBold",
  mono: "SpaceMono_400Regular",          // códigos (verificação e pedido)
  monoBold: "SpaceMono_700Bold",
};
