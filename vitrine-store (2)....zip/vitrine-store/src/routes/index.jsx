import React from "react";
import { View } from "react-native";
import { NavigationContainer, DefaultTheme, DarkTheme } from "@react-navigation/native";
import DrawerRoutes from "./DrawerRoutes";
import AuthStackRoutes from "./AuthStackRoutes";
import EmailBanner from "../components/EmailBanner";
import FadeIn from "../components/FadeIn";
import { useAuth } from "../context/AuthContext";
import { useTheme } from "../context/ThemeContext";

// ÚNICO NavigationContainer do app.
// Sem usuário logado → fluxo de login (Stack). Logado → Drawer → Bottom Tabs → Stack.
export default function Routes() {
  const { user } = useAuth();
  const { dark, colors } = useTheme();

  // Tema do React Navigation: cabeçalhos nativos, bordas e textos acompanham o modo claro/escuro
  const base = dark ? DarkTheme : DefaultTheme;
  const navTheme = {
    ...base,
    colors: { ...base.colors, primary: colors.primary, background: colors.background, card: colors.surface, text: colors.text, border: colors.border },
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <NavigationContainer theme={navTheme}>
        <FadeIn from={0} duration={500} style={{ flex: 1 }} key={user ? "app" : "auth"}>
          {user ? <DrawerRoutes /> : <AuthStackRoutes />}
        </FadeIn>
      </NavigationContainer>
      <EmailBanner />
    </View>
  );
}
