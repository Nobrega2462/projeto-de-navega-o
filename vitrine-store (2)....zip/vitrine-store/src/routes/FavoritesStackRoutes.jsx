import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Favorites from "../screens/Favorites";
import ProductDetails from "../screens/ProductDetails";
import { fonts } from "../theme";
import Header from "../components/Header";
import Background from "../components/Background";
import { useTheme } from "../context/ThemeContext";

const Stack = createNativeStackNavigator();

export default function FavoritesStackRoutes() {
  const { colors } = useTheme();
  return (
    <Stack.Navigator
      // screenLayout: envolve CADA tela com a foto de fundo (opaca, sem "vazar" durante a transição)
      screenLayout={({ children }) => <Background>{children}</Background>}
      initialRouteName="favorites"
      screenOptions={{ headerTintColor: colors.primary, headerTitleAlign: "center", headerTitleStyle: { fontFamily: fonts.bodySemi }, animation: "slide_from_right" }}
    >
      <Stack.Screen name="favorites" component={Favorites} options={{ header: () => <Header title="Favoritos" showCart /> }} />
      <Stack.Screen name="productDetails" component={ProductDetails} options={{ title: "Detalhes do produto", animation: "fade_from_bottom" }} />
    </Stack.Navigator>
  );
}
