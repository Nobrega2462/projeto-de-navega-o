import React from "react";
import { fonts } from "../theme";
import { View, Switch, StyleSheet } from "react-native";
import Text from "../components/Text";
import { createDrawerNavigator, DrawerContentScrollView, DrawerItemList } from "@react-navigation/drawer";
import { MaterialIcons } from "@expo/vector-icons";
import BottomRoutes from "./BottomRoutes";
import Profile from "../screens/Profile";
import Settings from "../screens/Settings";
import Help from "../screens/Help";
import About from "../screens/About";
import PrimaryButton from "../components/PrimaryButton";
import Background from "../components/Background";
import { useStore } from "../context/StoreContext";
import { useAuth } from "../context/AuthContext";
import { useThemed, useTheme } from "../context/ThemeContext";

const Drawer = createDrawerNavigator();

// Conteúdo personalizado do menu: cabeçalho + itens + botão que usa closeDrawer()
function CustomDrawerContent(props) {
  const { colors, styles } = useThemed(makeStyles);
  const { profile } = useStore();
  const { logout } = useAuth();
  const { dark, toggleTheme } = useTheme();
  return (
    <DrawerContentScrollView {...props} contentContainerStyle={{ paddingTop: 0 }}>
      <View style={styles.head}>
        <View style={styles.avatar}><MaterialIcons name="person" size={34} color={colors.primary} /></View>
        <Text style={styles.name}>{profile.name}</Text>
        <Text style={styles.mail}>{profile.email}</Text>
      </View>
      <DrawerItemList {...props} />
      {/* Alternador de tema: modo claro / escuro */}
      <View style={styles.themeRow}>
        <MaterialIcons name={dark ? "dark-mode" : "light-mode"} size={24} color={colors.textSoft} />
        <Text style={styles.themeText}>Modo escuro</Text>
        <Switch value={dark} onValueChange={toggleTheme} trackColor={{ true: colors.primary, false: colors.border }} thumbColor={colors.white} />
      </View>
      <View style={{ padding: 16 }}>
        <PrimaryButton title="Fechar menu" variant="outline" icon="close" onPress={() => props.navigation.closeDrawer()} />
        <PrimaryButton title="Sair da conta" icon="logout" onPress={logout} style={{ marginTop: 10 }} />
      </View>
    </DrawerContentScrollView>
  );
}

export default function DrawerRoutes() {
  const { colors, styles } = useThemed(makeStyles);
  return (
    <Drawer.Navigator
      screenLayout={({ children }) => <Background>{children}</Background>}
      initialRouteName="tabs"
      drawerContent={(props) => <CustomDrawerContent {...props} />}
      screenOptions={{
        headerShown: true, // telas Perfil/Config/Ajuda/Sobre usam o header do Drawer (com ☰)
        headerTintColor: colors.white,
        headerStyle: { backgroundColor: colors.primary },
        drawerPosition: "left",
        drawerType: "front", // exercício: teste "slide" ou "permanent"
        drawerActiveTintColor: colors.primary,
        drawerActiveBackgroundColor: colors.primaryLight,
        drawerInactiveTintColor: colors.textSoft,
        drawerLabelStyle: { fontSize: 15, fontFamily: fonts.bodySemi },
        headerTitleStyle: { fontFamily: fonts.bodySemi },
        drawerStyle: { backgroundColor: colors.surface, width: 290 },
        overlayColor: "rgba(17,24,39,0.5)",
      }}
    >
      {/* Navegação principal: as abas. headerShown:false evita header duplo */}
      <Drawer.Screen
        name="tabs"
        component={BottomRoutes}
        options={{
          headerShown: false,
          title: "Loja",
          drawerLabel: "Loja",
          drawerIcon: ({ color, size }) => <MaterialIcons name="storefront" size={size} color={color} />,
        }}
      />
      <Drawer.Screen name="profile" component={Profile} options={{ title: "Perfil", drawerLabel: "Perfil", drawerIcon: ({ color, size }) => <MaterialIcons name="person" size={size} color={color} /> }} />
      <Drawer.Screen name="settings" component={Settings} options={{ title: "Configurações", drawerLabel: "Configurações", drawerIcon: ({ color, size }) => <MaterialIcons name="settings" size={size} color={color} /> }} />
      <Drawer.Screen name="help" component={Help} options={{ title: "Ajuda", drawerLabel: "Ajuda", drawerIcon: ({ color, size }) => <MaterialIcons name="help-outline" size={size} color={color} /> }} />
      <Drawer.Screen name="about" component={About} options={{ title: "Sobre a loja", drawerLabel: "Sobre a loja", drawerIcon: ({ color, size }) => <MaterialIcons name="info-outline" size={size} color={color} /> }} />
    </Drawer.Navigator>
  );
}
const makeStyles = (colors) => StyleSheet.create({
  themeRow: { flexDirection: "row", alignItems: "center", paddingHorizontal: 18, paddingVertical: 8 },
  themeText: { flex: 1, marginLeft: 16, fontSize: 15, fontWeight: "600", color: colors.textSoft },
  head: { backgroundColor: colors.primary, padding: 20, paddingTop: 48, marginBottom: 8 },
  avatar: { width: 60, height: 60, borderRadius: 30, backgroundColor: colors.white, alignItems: "center", justifyContent: "center" },
  name: { fontFamily: fonts.heading, color: colors.white, fontSize: 18, fontWeight: "700", marginTop: 10 },
  mail: { color: "#DDD6FE", fontSize: 13 },
});
