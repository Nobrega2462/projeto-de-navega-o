import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Home from "../screens/Home";
import ProductDetails from "../screens/ProductDetails";
import { fonts } from "../theme";
import Header from "../components/Header";
import Background from "../components/Background";
import { useTheme } from "../context/ThemeContext";

// Navegadores SEMPRE criados fora do componente (evita recriação a cada render)
const Stack = createNativeStackNavigator();

export default function HomeStackRoutes() {
  const { colors } = useTheme();
  return (
    <Stack.Navigator
      // screenLayout: envolve CADA tela com a foto de fundo (opaca, sem "vazar" durante a transição)
      screenLayout={({ children }) => <Background>{children}</Background>}
      initialRouteName="home"
      screenOptions={{ headerTintColor: colors.primary, headerTitleAlign: "center", headerTitleStyle: { fontFamily: fonts.bodySemi }, animation: "slide_from_right" }}
    >
      <Stack.Screen name="home" component={Home} options={{ header: () => <Header showSearch showCart /> }} />
      <Stack.Screen name="productDetails" component={ProductDetails} options={{ title: "Detalhes do produto", animation: "fade_from_bottom" }} />
    </Stack.Navigator>
  );
}
