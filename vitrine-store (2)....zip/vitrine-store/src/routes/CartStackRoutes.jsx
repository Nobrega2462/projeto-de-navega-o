import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Cart from "../screens/Cart";
import Checkout from "../screens/Checkout";
import OrderConfirmation from "../screens/OrderConfirmation";
import { fonts } from "../theme";
import Header from "../components/Header";
import Background from "../components/Background";
import { useTheme } from "../context/ThemeContext";

const Stack = createNativeStackNavigator();

// Fluxo de compra: Carrinho → Checkout → Confirmação
export default function CartStackRoutes() {
  const { colors } = useTheme();
  return (
    <Stack.Navigator
      // screenLayout: envolve CADA tela com a foto de fundo (opaca, sem "vazar" durante a transição)
      screenLayout={({ children }) => <Background>{children}</Background>}
      initialRouteName="cart"
      screenOptions={{ headerTintColor: colors.primary, headerTitleAlign: "center", headerTitleStyle: { fontFamily: fonts.bodySemi }, animation: "slide_from_right" }}
    >
      <Stack.Screen name="cart" component={Cart} options={{ header: () => <Header title="Meu carrinho" /> }} />
      <Stack.Screen name="checkout" component={Checkout} options={{ title: "Finalizar compra" }} />
      {/* Sem botão de voltar: o pedido já foi criado (checkout usa replace) */}
      <Stack.Screen name="orderConfirmation" component={OrderConfirmation} options={{ title: "Pedido confirmado", headerBackVisible: false, gestureEnabled: false, animation: "fade_from_bottom" }} />
    </Stack.Navigator>
  );
}
