import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Login from "../screens/Login";
import Register from "../screens/Register";
import VerifyEmail from "../screens/VerifyEmail";

const Stack = createNativeStackNavigator();

// Fluxo de autenticação (exibido enquanto não há usuário logado)
export default function AuthStackRoutes() {
  return (
    <Stack.Navigator initialRouteName="login" screenOptions={{ headerShown: false, animation: "slide_from_right" }}>
      <Stack.Screen name="login" component={Login} />
      <Stack.Screen name="register" component={Register} />
      <Stack.Screen name="verifyEmail" component={VerifyEmail} options={{ animation: "fade_from_bottom" }} />
    </Stack.Navigator>
  );
}
