import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { MaterialIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import HomeStackRoutes from "./HomeStackRoutes";
import ProductStackRoutes from "./ProductStackRoutes";
import FavoritesStackRoutes from "./FavoritesStackRoutes";
import CartStackRoutes from "./CartStackRoutes";
import { fonts } from "../theme";
import { useStore } from "../context/StoreContext";
import { useTheme } from "../context/ThemeContext";

const Tab = createBottomTabNavigator();

export default function BottomRoutes() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets(); // respeita a área segura do aparelho
  const { totalItems } = useStore(); // contador do carrinho vem do estado global

  return (
    <Tab.Navigator
      initialRouteName="homeTab"
      screenOptions={{
        headerShown: false, // quem mostra cabeçalho são os Stacks internos
        animation: "fade", // efeito ao trocar de aba ("shift", "fade" ou "none")
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.gray,
        tabBarShowLabel: true, // exercício: mude para false para ocultar os textos
        tabBarLabelStyle: { fontSize: 12, fontFamily: fonts.bodySemi },
        tabBarStyle: {
          backgroundColor: colors.surface,
          borderTopColor: colors.border,
          height: 58 + insets.bottom,
          paddingBottom: insets.bottom + 6,
          paddingTop: 6,
        },
      }}
    >
      <Tab.Screen
        name="homeTab"
        component={HomeStackRoutes}
        options={{
          tabBarLabel: "Início",
          tabBarIcon: ({ color, size }) => <MaterialIcons name="home" size={size} color={color} />,
        }}
      />
      <Tab.Screen
        name="productsTab"
        component={ProductStackRoutes}
        options={{
          tabBarLabel: "Produtos",
          tabBarIcon: ({ color, size }) => <MaterialIcons name="storefront" size={size} color={color} />,
        }}
      />
      <Tab.Screen
        name="favoritesTab"
        component={FavoritesStackRoutes}
        options={{
          tabBarLabel: "Favoritos",
          // ícone muda entre cheio (ativo) e contornado (inativo)
          tabBarIcon: ({ color, size, focused }) => (
            <MaterialIcons name={focused ? "favorite" : "favorite-border"} size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="cartTab"
        component={CartStackRoutes}
        options={{
          tabBarLabel: "Carrinho",
          tabBarIcon: ({ color, size }) => <MaterialIcons name="shopping-cart" size={size} color={color} />,
          // undefined = badge some quando o carrinho está vazio
          tabBarBadge: totalItems > 0 ? totalItems : undefined,
          tabBarBadgeStyle: { backgroundColor: colors.danger, color: colors.white, fontSize: 11 },
        }}
      />
    </Tab.Navigator>
  );
}
